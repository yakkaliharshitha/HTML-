
public class Last {


	int count=0;

 String myReplace(String str,char CharFind, char Charreplace)
 {
  char[] arr=str.toCharArray();
   for(int i=str.length()-1;i>=0;i--){
	if((arr[i]==CharFind)&&(count==0)) {
		  count++;
	    arr[i]=Charreplace;
		     }
	   
          
   }
String manStr=new String(arr);
return manStr;
}


public static void main(String[] args) {

Last r=new Last();
String data=r.myReplace("test data", 'a', '@');

System.out.println(data);

}

}





