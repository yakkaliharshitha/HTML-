


public class Alphacomp {

	public static boolean checkEqual(char c1, char c2) {
		boolean f=true;
		if(Character.toLowerCase(c1)==Character.toLowerCase(c2)){
			f=true;
		}
		
		else {
			f=false;
		}  
		
		return f;
	}
	
	
	
	
	public static void main(String[] args) {
		System.out.println(checkEqual('b','A'));
		
	}

}
