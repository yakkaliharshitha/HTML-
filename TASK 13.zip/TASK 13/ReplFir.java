
public class ReplFir {
	int count=0;

String myReplace(String str,char CharFind , char Charreplace)
{
char[] arr=str.toCharArray();
   for(int i=0;i<str.length();i++){
	if((arr[i]==CharFind) && (count==0)){
		count++;
		arr[i]=Charreplace;
		//break;
        
	      }
	   //break;
          }

String manStr=new String(arr);
return manStr;
}

public static void main(String[] args) {

ReplFir r=new ReplFir();
String data=r.myReplace("test data", 't', '@');

System.out.println(data);

}

}



