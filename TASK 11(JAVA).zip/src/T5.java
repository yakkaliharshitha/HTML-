
public class T5 {
	
	

		public static void main(String[] args) {

int sum;

		sum=((Integer.parseInt(args[0]))+(Integer.parseInt(args[1])));
		System.out.println("The sum is "+sum);


		}
}

		

