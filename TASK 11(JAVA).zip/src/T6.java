
public class T6 {

	
public static void main(String[] args) {

	

		System.out.println(args[0]+args[1]);


		}
		}

