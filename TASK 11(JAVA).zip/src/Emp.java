
public class Emp {
	String name;
	int phnnum;
	int id;
	String desg;
	float salary;

	
	void init() {
		 name="Harshu";
		 phnnum=986767;
		 id=979;
		 desg="APSE";
		 salary=25000.0f;
	}
	
	void init2() {
		 name="Abhi";
		 phnnum=9867623;
		 id=909;
		 desg="APSS";
		 salary=2500.0f;
	}
	
	void init3() {
		 name="Usha";
		 phnnum=9868623;
		 id=809;
		 desg="APES";
		 salary=25000.0f;
	}
	
	
	void disp() {
		System.out.println(" Employee Name is " +name);
		System.out.println(" Employee phone number is "+phnnum);
		System.out.println(" Employee id is "+id);
		System.out.println(" Employee designation is "+desg);
		System.out.println(" Employee salary is "+salary);
		
	}
	
	public static void main(String[] args) {
		
		Emp e = new Emp();
		Emp e1 = new Emp();
		Emp e2 = new Emp();
		e.init();
		e.disp();
		e1.init2();
		e1.disp();
		e2.init3();
		e2.disp();

	}

}
