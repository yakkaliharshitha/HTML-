
public class T2 {

	public static void main(String[] args) {
		int num=23;
		if(num%2==0) {
			System.out.println("The input is Even number");
		}
		else if(num%2!=0) {
			System.out.println("The input is odd number");
		}
	}

}
