
public class T4 {
	

		public static void main(String[] args) {



		System.out.println("args1-->"+args[0]);
		System.out.println("args2-->"+args[1]);
		System.out.println("welcome to "+args[1]+" training  @"+args[0]);



		}
		}


