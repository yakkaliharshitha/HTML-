
public class T3 {

	public static void main(String[] args) {
		
		
		int dollar=2;
		float rupee;
		float c=74.83f;
		rupee=dollar*c;
		System.out.println("The conversion of dollar to rupee is"+rupee);

	}

}
