
public class Task1 {

	public static void main(String[] args) {
		
		
	char a='j';
	
	
	
	if(a>=65 && a<=90) {
		System.out.println("The input is Capital");
	}
    else if(a>=97 && a<=122) {
		System.out.println("The input is Small");
	}
	else {
		System.out.println("Invalid input");
	}
			

	}

}
