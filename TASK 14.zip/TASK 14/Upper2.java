
public class Upper2 {

	public static String hasUpper(String data)
	{
		String chk = "  ";
	  char[] arr=data.toCharArray();
		
       for( int i=0;i<data.length();i++) {
		
		if(arr[i]>=65 && arr[i]<=90) {
			
	           chk="True";
	           
			   }
		else {
			
			  chk="False";
		   }
	         }
       // System.out.println(chk);
           return chk;
		
       
		 }
		
	public static void main(String[] args) {
	//	Upper2 u=new Upper2();
		//u.hasUpper("H");
		System.out.println(hasUpper("ABC"));
	}

}


