
public class Upper3 {

static int count;
	
	 public void  isCapsNum(String data) {
		
		 
		 
		char[] arr=data.toCharArray();
		
       for( int i=0;i<data.length();i++) {
		
		if(arr[i]>=65 && arr[i]<=90) {
			count ++;
			}
		
       }
		
		System.out.println("The number of capitals are "  +count);
			
		
	 
	 }
		
	public static void main(String[] args) {
		Upper3 u=new Upper3();
		u.isCapsNum("jHYAAJoxdsz");
	
		
		}

}



