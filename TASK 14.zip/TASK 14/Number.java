
public class Number {
	
	public static boolean isNum(String data) {
		
		 boolean f=true;
		 
		char[] arr=data.toCharArray();
		
      for( int i=0;i<data.length();i++) {
		
		if(arr[i]>=48 && arr[i]<=57) {
			
	           f=true;
			
		}
		else {
			f=false;
		}
      }
		
		return f;
			 }
		
	public static void main(String[] args) {
		System.out.println(isNum("hyfg"));
	
		
		
		}

}





