
public class d7Address {
	String streetName;
	int pinNo;


	public String getStreetName() {
	return streetName;
	}


	public void setStreetName(String streetName) {
	this.streetName = streetName;
	}


	public int getPinNo() {
	return pinNo;
	}


	public void setPinNo(int pinNo) {
	this.pinNo = pinNo;
	}


	public d7Address(String streetName, int pinNo) {
	super();
	this.streetName = streetName;
	this.pinNo = pinNo;
	}


	@Override
	public String toString() {
	return " [streetName=" + streetName + ", pinNo=" + pinNo + "]";
	}


	/*@Override
	public String toString() {
	return getStreetName()+ " "+getPinNo();
	}*/
	}



