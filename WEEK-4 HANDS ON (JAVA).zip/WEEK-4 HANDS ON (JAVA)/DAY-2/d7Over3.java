class A{
public  void move(){
System.out.println("Animal Move");
}
}
class T extends A{


public void move(){
System.out.println("Tiger Move");
}

}



public class d7Over3 {
	public static void main(String[] args) {
		T t=new T();
		t.move();
		}
		}



