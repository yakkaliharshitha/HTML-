public class d7sss {
	  abstract class shape{
			public abstract void draw() ;
				 }
		  
		  
		  class circle extends shape{

			@Override
			public void draw() {
				System.out.println("In circle");
				}
			  }
		  class triangle extends shape{

			@Override
			public void draw() {
				System.out.println("In triangle");
				
			}
			  
		  }
		  
	
	public static void main(String[]args) {
	
		
	}
	

}
