class Calc{
	int x=90;
 void sum(){
System.out.println("sum method");
}
public void mul(){
System.out.println("mul method");
}
}

class SciCalc extends Calc{
	int x=50;
	
	SciCalc(){
		System.out.println("Hii i am in child class");
		
	}
	
	SciCalc( int x){
		System.out.println("Hii i am in child class and x is " +super.x);
		
	}

}

public class d7Inheritance {

public static void main(String[] args) {
SciCalc sc=new SciCalc();
sc.sum();
sc.mul();
SciCalc sc1=new SciCalc(40);
}

}
