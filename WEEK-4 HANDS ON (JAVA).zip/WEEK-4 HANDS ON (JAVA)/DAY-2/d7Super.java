 class parent{
int x=10;
public parent() {
System.out.println("p const");
}
public parent(int  x) {
System.out.println("p const args");
}
}

class child extends parent{
int x=50;
public child() {
	
super(10);
}
void abc(){
	int x=30;
System.out.println("val of x = "+x);
}
}




public class d7Super {

public static void main(String[] args) {
child sc=new child();

sc.abc();
}


}
