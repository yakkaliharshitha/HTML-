
public class d7Student {
	int studId;
	String name;
	d7Address address;
	public d7Student(int studId, String name, d7Address address) {
	super();
	this.studId = studId;
	this.name = name;
	this.address = address;
	}
	public int getStudId() {
	return studId;
	}
	public void setStudId(int studId) {
	this.studId = studId;
	}
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public d7Address getAddress() {
	return address;
	}
	public void setAddress(d7Address address) {
	this.address = address;
	}
	@Override
	public String toString() {
	return "Student [studId=" + studId + ", name=" + name + ", address=" + address + "]";
	}


}


