//final -> var method class
// final int x; // x=0;
public class d7Final2 {
	
	

	final int x;

	public d7Final2() {
	x=50;
	}

	void abc()
	{

	System.out.println(x);

	}

	public static void main(String[] args) {

	new d7Final2().abc();
	}

	}



