class Ani{
 void move(){
System.out.println("Animal Move");
}
}
class Tig extends Ani{

@Override
public void move(){
System.out.println("Tiger Move");
}

}




public class d7Overriding2 {
	public static void main(String[] args) {
		Tig t=new Tig();
		t.move();
		}

}
