//over riding : modifying parents behaviour

	// no of args ,type n seq must be same
	// return type must be same
	// access spcfr -> must be same or higher

	//public
	//protected
	//default
	//private
    //final

	
	
	class An{

	private final void move(){
	System.out.println("Animal Move");
	}

	}
	class Ti extends An{

	public void move(){
	  System.out.println("tiger Move");
	  }
	 
	}

	public class d7Final3 {
	public static void main(String[] args) {
	Ti t=new Ti();
	t.move();

	}
	}


