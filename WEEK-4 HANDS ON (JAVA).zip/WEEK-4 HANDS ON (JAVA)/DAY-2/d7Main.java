
public class d7Main {
	public static void main(String[] args) {

		d7Address address=new d7Address("M G Road", 101);

		d7Student student=new d7Student(1, "RAJ", address);


		System.out.println(student);

		}

}
