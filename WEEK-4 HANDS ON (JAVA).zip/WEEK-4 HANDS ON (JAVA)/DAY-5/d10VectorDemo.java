import java.util.Vector;
//  map -- key-value key is unique

// list -- ordered  - allows duplicates

// set -- unordered- unique

//collection of elements of type object

public class d10VectorDemo {

public static void main(String[] args) {

Vector v=new Vector();
v.add("hello");


v.add("vector");
v.add("lets");
v.add("Rock");
System.out.println(v.size());

v.add("...");
v.add("Hii");

System.out.println(v.size());

System.out.println(v);

v.insertElementAt("List", 1);

System.out.println(v);
v.remove(1);
System.out.println(v);

System.out.println(v.size());

}



}



