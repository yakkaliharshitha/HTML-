import java.util.Vector;

//  map -- key-value key is unique

// list -- ordered  - allows duplicates

// set -- unordered- unique

//collection of elements of type object

public class d10VectorDemo2 {

public static void main(String[] args) {

Vector<Integer> marks=new Vector<Integer>();
Vector<Character> cha=new Vector<Character>();
Vector<String>S =new Vector<String>();
Vector<Float> F=new Vector<Float>();
marks.add(50);
marks.add(60);
marks.add(70);

int x=11;
marks.add(x);//auto boxing
System.out.println(marks);

cha.add('H');
cha.add('a');
cha.add('r');
cha.add('s');
cha.add('h');
cha.add('u');
char c='u';
cha.add(c);
//cha.remove(1);
System.out.println(cha);


S.add("HII");
S.add("VECTOR");
System.out.println(S);
F.add(34.5f);
System.out.println(F);
}



}




