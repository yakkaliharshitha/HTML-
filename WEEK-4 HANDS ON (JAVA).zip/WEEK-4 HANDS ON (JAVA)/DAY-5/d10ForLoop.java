import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

//collection of elements of type object

// list -- ordered  - allows duplicates

// set -- unordered- unique

//map -- key-value key is unique


public class d10ForLoop {

public static void main(String[] args) {

Vector<d6StudentDemo> hs=new Vector<>();

d6StudentDemo sd1=new d6StudentDemo("Raj", 1);
d6StudentDemo sd2=new d6StudentDemo("Raja", 2);
d6StudentDemo sd3=new d6StudentDemo("Raju", 5);
d6StudentDemo sd4=new d6StudentDemo("Ram", 4);

hs.add(sd1);
hs.add(sd2);
hs.add(sd3);
hs.add(sd4);
hs.add(sd4);


for(d6StudentDemo sd:hs)
{
sd.dispStudent();
}

}



}





