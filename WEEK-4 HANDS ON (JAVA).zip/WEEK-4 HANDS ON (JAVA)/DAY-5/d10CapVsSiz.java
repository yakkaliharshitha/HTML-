import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

//collection of elements of type object

// list -- ordered  - allows duplicates

// set -- unordered- unique

//map -- key-value key is unique


/*
 * 1 --- Raj
 * 2  --- Ram
 * 3 --- Raja
 * 4 ---Raju
 *
 *
 */

//create a map ton search stud based on d rollno
public class d10CapVsSiz {

public static void main(String[] args) {


Vector<Integer> v=new Vector<>(6,4);
//capacity: it can store 6 elements

System.out.println(v.size());//no elements added size is zero
System.out.println(v.capacity());// capacity is 6 which is given as a arg while creating vector object
//---------------------------------

v.add(110);
v.add(110);
v.add(110);

System.out.println(v.size());//3 elements added size is 3
System.out.println(v.capacity());// capacity is 6 which is given as a arg while creating vector object


//----------------------------

System.out.println("--------------");
v.add(110);
v.add(110);
v.add(110);

System.out.println(v.size());//6 elements added size is 6
System.out.println(v.capacity());// capacity is 6 which is given as a arg while creating vector object

//-----------------------------------

System.out.println("--------------");
v.add(110);

System.out.println(v.size());// elements added 7 size is 7
System.out.println(v.capacity());
// capacity was 6 which is given as a arg while creating vector object
//as size goes beyond d capacity .. d capacity in increased which is
//actully given as d second arg while creating vector obj
//if 2nd arg  is not given it is same as d frst arg



}

}





