import java.io.FileNotFoundException;

public class d9checkvsuncheck {
public static void main(String[] args) {
	
//System.out.println(10/0);

//Class.forName("saSASA");

//throw new ArithmeticException();

//throw new ArrayIndexOutOfBoundsException();

//throw new NullPointerException();

//throw new ClassNotFoundException();

//throw new FileNotFoundException();

}
}
 

// exception Handling
// try catch finally throw throws




