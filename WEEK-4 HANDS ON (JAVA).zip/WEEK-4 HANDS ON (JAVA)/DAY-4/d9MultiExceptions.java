// 12
// 6
// try catch --> cannot div a num by zero plz provide some other input
//--> dont not use zero in ur input
// book ticket


public class d9MultiExceptions {

public static void main(String[] args) {

try{
int[] x={12,0,5};
System.out.println("line 3 ---"+(10/0));
System.out.println(x[4]);
System.out.println("try ends");
}
catch (ArithmeticException e) {
System.out.println("huh ? trying to div the num by zero ? which school bro ?");
System.out.println(e);
}
catch (ArrayIndexOutOfBoundsException e) {
System.out.println(e);
}

System.out.println("Line 1");
System.out.println("Line 2");
}
}
 

// exception Handling
// try catch finally throw throws






