//message -- getMessage()
class TicketNotFoundException extends Exception{

public TicketNotFoundException() {
super(" Sorry you are Out of Stock ");
}
}

class BookMyShow
{
void bookTicket(int NoOfTickets)throws TicketNotFoundException
{
if(NoOfTickets > 5)
throw new TicketNotFoundException();

else
System.out.println(NoOfTickets +" tickets Booked enjoy the show");
}

}
public class d9MyExceptionDemo {
	public static void main(String[] args) {
		BookMyShow b=new BookMyShow();

		try{
		b.bookTicket(6);
		}
		catch (Exception e) {
		//e.printStackTrace();
		System.out.println(e);
		}

		System.out.println("end of main");
		}

		}


