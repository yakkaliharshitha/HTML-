
public class d9ExceptionHandlingMain {
	public void test()
	{
	System.out.println(10/0);
	}

	public static void main(String[] args) {

	try{
	new d9ExceptionHandlingMain().test();
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	System.out.println("line 1");

	}
	}

