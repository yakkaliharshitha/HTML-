
public class d9HandlingException {
	public void test()
	{
	System.out.println(10/0);
	}

	public static void main(String[] args) {

	try{
	new d9HandlingException().test();
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	System.out.println("line 1");

	}
	}


