
public class d9MultiCatchBlocks {

	public static void main(String[] args) {

		try{
		int[] x={12,0,5};
		System.out.println("line 3"+(10/x[9]));// flow stops

		}
		catch (ArithmeticException e) {
		System.out.println("huh ? trying to div the num by zero ? why bro ?");
		System.out.println("In first catch block");
		System.out.println(e);
		}
		catch (ArrayIndexOutOfBoundsException e) {
	    System.out.println("In second catch block");
		System.out.println(e);
		}

		System.out.println("Line 1");
		System.out.println("Line 2");
		}
		}
		 

		// exception Handling
		// try catch finally throw throws


