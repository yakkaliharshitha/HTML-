public class d9Throws{
// throws redirects the exception to the caller (one who invokes the method)
//throw : raises an exception
public void test()throws ClassNotFoundException{

Class.forName("");
}

public static void main(String[] args) {

try
{
new d9Throws().test();
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

System.out.println("line 1 end of main");

}
}
 
	


