

	//abs class can have non abs meths
	//intrfc set of abs methods (interface meths cannot have body)
	//interface meths abs by default
	// abs class can have cont
	// interface cannot have const

	// abs class shares d comon bhvr among rltd classes
	//interface shares d comon bhvr among non rltd classes

	//

	interface MyInter
	{
	void test(); // public

	}

	public class d8InterDemo implements MyInter{

	public void test() //default
	{

	}

	public static void main(String[] args) {

	}


}
