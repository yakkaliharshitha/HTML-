interface myinterde{
void test();
}

interface interchil extends myinterde{
void abc();
}

public class d8InterDemo3 implements interchil{
@Override
public void abc() {
}
@Override
public void test() {
}

public static void main(String[] args) {
}


}

