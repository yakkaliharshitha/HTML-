
public class d8Dev3 {
	public static void main(String[] args) {

		d8Dev1 d=new d8Dev1();
		d8Dev2 d2=new d8Dev2();

		d2.saveData(d);


		}

}
