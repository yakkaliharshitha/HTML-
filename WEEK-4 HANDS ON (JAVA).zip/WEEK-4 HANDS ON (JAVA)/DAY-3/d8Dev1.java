interface AllowStorage{

}

public class d8Dev1 implements AllowStorage{

}
