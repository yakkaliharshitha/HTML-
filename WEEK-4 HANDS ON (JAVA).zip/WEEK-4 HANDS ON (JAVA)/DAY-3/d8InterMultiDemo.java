interface myinterdemoo{
void test();
}

interface myinterdemo1{
void test1();
}

interface interchi extends myinterdemoo,myinterdemo1{
void abc();
}

public class d8InterMultiDemo implements interchi{


public static void main(String[] args) {
}

@Override
public void test() {
// TODO Auto-generated method stub

}

@Override
public void test1() {
// TODO Auto-generated method stub

}

@Override
public void abc() {
// TODO Auto-generated method stub

}
}

