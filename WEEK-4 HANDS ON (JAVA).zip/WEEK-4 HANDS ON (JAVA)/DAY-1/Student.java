package pack1;

public class Student {
	//int x=10;
	public static int x=10;
	public static int y=20;

	public void abc()
	{
	System.out.println(x);
	}


	public void testMeth()
	{
	System.out.println("test meth from stud class");
	}
	

	public void testMethNew()
	{
	System.out.println("test meth new from stud class");

}
}
