package pack2;

//import pack1.Customer;
//import pack1.Student;


import pack1.*;
//load all classes from the package

public class DemoPackage {
	
	
		static int x=50;
		public static void main(String[] args) {
		Student student=new Student();
		//student.abc();

		System.out.println(Student.x);
		//System.out.println(y);
		

		

		
	}

}
