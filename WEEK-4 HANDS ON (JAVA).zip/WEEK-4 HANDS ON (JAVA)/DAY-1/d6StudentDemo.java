
public class d6StudentDemo {
	
	private String name;
	private int rollNo;


	public void setName(String name)
	{
	this.name=name;
	}

	public void setRollNo(int rollNo)
	{
	if(!(rollNo>50))
	this.rollNo=rollNo;
	}


	public void dispStudent(){
	System.out.println(name+" "+rollNo);
	}

	public d6StudentDemo(String name, int rollNo) {
	this.name = name;
	this.rollNo = rollNo;
	}

	}



