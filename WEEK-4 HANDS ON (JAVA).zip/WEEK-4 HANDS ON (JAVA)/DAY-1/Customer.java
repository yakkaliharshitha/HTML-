package pack1;

public class Customer {
	
	public void testCust()
	{
	System.out.println("CUSTOMER CLASS");
	}
	
	
	public static void main(String[] args) {

		Student st=new Student();
		st.x=50;
		System.out.println(st.x);
		}
		}


