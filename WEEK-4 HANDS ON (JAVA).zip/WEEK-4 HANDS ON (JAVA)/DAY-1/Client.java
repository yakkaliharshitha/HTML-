package pack1.sub;

public class Client {
	
	public void clientMeth()
	{

	System.out.println("client method");
	}
	

}
