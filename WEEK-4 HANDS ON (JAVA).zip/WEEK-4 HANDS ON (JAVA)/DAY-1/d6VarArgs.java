
public class d6VarArgs {
	
	 public static int sum(int... x){
		 int add=0,big=0,small=0;
		 int [] even= new int[x.length];
		 int [] odd= new int[x.length];
		for(int i=0;i<x.length;i++) {
			for( int j=0;j<even.length;j++) {
				
			  add=add+x[i];
			 
			  
			     if(x[i]%2==0) {
				  even[j]=x[i];
			     System.out.println("The even numbers are " +even[j]);
			     break;
			     }
				  else { 
				   odd[j]=x[i];
				   System.out.println("The odd numbers are " +odd[j]);
				   break;
				  }
				  }
			}
		
		
		System.out.println("The sum is " +add);
		
		
		for(int k=0;k<x.length;k++) {
			if(x[k]<x[k+1]) {
				small=x[k];
			System.out.println("The small number  is " +small);
			break;
			}}
			for(int l=0;l<x.length;l++) { 
			if(x[l]>x[l+1]) {
				big=x[l];
			System.out.println("The big number  is " +big);
				break;
				}
			
		}
			for(int m=0;m<x.length;m++) {
				if(x[m]%3==0) {
					System.out.println(x[m]);
				}
			}
			
		
	   return add;
	}
	 



	public static void main(String[] args) {
	d6VarArgs c=new d6VarArgs();
	sum(10,1,4);
	}

	}



