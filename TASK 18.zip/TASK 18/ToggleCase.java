
public class ToggleCase {
	String ToggleCase(String str) {
		int count=0;
		char[] arr=str.toCharArray();
		for(int c=0;c<str.length();c++)
	     {
	         if(arr[c]>=65 && arr[c]<=90)
	         {
	             arr[c]=(char)((int)arr[c]+32);
	         }
	         else if(arr[c]>=97 && arr[c]<=122)
	         {
	             arr[c]=(char)((int)arr[c]-32);
	         }
	     }
		for(int j=0;j<str.length();j++) {
			System.out.print(arr[j]);
		}
		return " ";
	}
	public static void main(String[] args) {
		ToggleCase t= new ToggleCase();
		t.ToggleCase("HEllo");
		
	}

}
	


