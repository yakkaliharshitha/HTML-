
public class Revcase {
	String RevCase(String str){
		int count=0;
		char arr[]=str.toCharArray();
		char rev[]=new char[str.length()];
	    for(int i=0;i<arr.length;i++) {
		rev[i]=arr[arr.length-i-1];
		//System.out.print(rev[i]);
	    }
	   for(int i=0;i<arr.length;i++)
		{
		if(rev[i]>='A' && rev[i]<='Z') {
		rev[i]=(char)((int)rev[i]+32);
		//System.out.print(rev[i]);
		}
		
		if(arr[i]>='A' && arr[i]<='Z') {
			count++;
		rev[i]=(char)((int)rev[i]-32);
		//System.out.print(arr[i]);
		//System.out.print(" ");
		//if(count<=2)
		//System.out.print(rev[i]);
		//else 
		//System.out.print(rev[i-1]);
		}
		
		}
	   for(int k=0;k<str.length();k++) {
		  System.out.print(rev[k]);
	   }
	   return " ";
		}

	public static void main(String[] args) {
		Revcase r= new Revcase();
	    System.out.print(r.RevCase("HeLloWorld"));
	}
}
