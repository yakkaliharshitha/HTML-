
public class RevStr {
	 String RevStr(String str) {
			
			char[] arr=str.toCharArray();
				
			String reverse=" ";
			
			for(int i=str.length()-1;i>=0;i--){
			reverse+=arr[i];
			
			
			}
			System.out.println(reverse);
			return " ";
			}
			
			

	
public static void main(String[] args) {
		  
	RevStr r= new RevStr();
	r.RevStr("Hello");
		

	}

}


