
public class LowerCase {
	String LowerCase(String str) {
	int count=0;
	char[] arr=str.toCharArray();
	for(int i=0;i<str.length();i++){
		if(arr[i]>=97 && arr[i]<=122)
			count++;
			//System.out.println("ok");
		else {
			arr[i]=(char) (arr[i]+32);
		}
		//if( !(arr1[i]==arr2[i] || arr1[i]==(arr2[i]+32) )
		
		
	}
	for(int j=0;j<str.length();j++) {
		System.out.print(arr[j]);
	}
	return " ";
	}
	public static void main(String[] args) {
		LowerCase l = new LowerCase();
		l.LowerCase("HELLOworld");
	
		
	}

}
