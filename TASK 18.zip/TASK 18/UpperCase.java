
public class UpperCase{ 
	String UpperCase(String str) {
	int count=0;
	char[] arr=str.toCharArray();
	for(int i=0;i<str.length();i++){
		if(arr[i]>=66 && arr[i]<=90)
			count++;
			//System.out.println("ok");
		else {
			arr[i]=(char) (arr[i]-32);
		}
		//if( !(arr1[i]==arr2[i] || arr1[i]==(arr2[i]+32) )
		
		
	}
	for(int j=0;j<str.length();j++) {
		System.out.print(arr[j]);
	}
	return " ";
	}
	public static void main(String[] args) {
		UpperCase u= new UpperCase();
		u.UpperCase("HelloWorld");
		
	}

}
