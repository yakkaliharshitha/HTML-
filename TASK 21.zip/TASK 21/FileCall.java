import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
public class FileCall {
	public static void main(String[]args) {
		int a1=0;
		int a2=0;
		int a3=0;
		int a4=0;
		try {
			File f = new File("te.txt");
			FileReader fr=new FileReader(f);
			BufferedReader br=new BufferedReader(fr);
			br.readLine();
			String string = br.readLine();
			ArrayList<Student> stud=new ArrayList<Student>();
			if(string==null) {
				System.out.println("No list found");
			}
			while(!(string==null)) {
			string=string.trim();
			
			String[] arr1=string.split(",");
			a1=Integer.parseInt(arr1[0]);
			//System.out.println(arr1[0]);
			a2=Integer.parseInt(arr1[1]);
			//System.out.println(arr1[1]);
			a3=Integer.parseInt(arr1[4]);
			//System.out.println(arr1[4]);
			a4=Integer.parseInt(arr1[5]);
			//System.out.println(arr1[5]);
			//System.out.println(arr1[2]+" "+arr1[3]);
	Student ss1 = new Student(a1,a2,arr1[2],arr1[3],a3,a4);
	
			stud.add(ss1);
			string=br.readLine();
			int n=0;
			
			}
			for(Student ss2:stud){
			System.out.println(ss2);
			}
			
			}
			catch (FileNotFoundException e) {
				System.out.println("Sorry improper or no  file list found");
			e.printStackTrace();
			} catch (IOException e) {
				System.out.println("Sorry improper or no file list found");
			e.printStackTrace();
			}
		 System.out.println("---------------------------------End of the list----------------------------------------");
			}
	     
			}

			
		
	
	


