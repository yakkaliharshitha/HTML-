import java.util.ArrayList;

public class Main {
	ArrayList<Student> studList=new ArrayList<>();
	
	public static void main(String[] args) {
		
		Student s1=new Student(1000,1,"Shikhar","Male",1,60);
		Student s2=new Student(1001,1,"Rohit","Male",5,70);
		Student s3=new Student(1000,1,"Shikhar","Male",1,60);
		Student s4=new Student( 1002,1,"VIRAT","Male",1,65);
		Student s5=new Student(1003,1,"priya","FeMale",3,100);
		Student s6=new Student(1004,1,"neha","FeMale",3,90);
		Student s7=new Student(1001,1,"Rohit","Male",5,70);
		Student s8=new Student(1000,1,"Shikhar","Male",1,60);
		Student s9=new Student(1000,1,"Shikhar","Male",1,60);
		Student s10=new Student(1000,1,"Shikhar","Male",1,60);
		ArrayList<Student> std1=new ArrayList<>();
		std1.add(s1);
		std1.add(s2);
		std1.add(s3);
		std1.add(s4);
		std1.add(s5);
		std1.add(s6);
		std1.add(s7);
		std1.add(s8);
		std1.add(s9);
		std1.add(s10);
		System.out.println(std1);
	}

}
