
public class Alphaloop {

	public static void main(String[] args) {
		
		 for(char i=65; i <= 90; i++)
	        {
	            System.out.println(i);
	        }

	}

}
