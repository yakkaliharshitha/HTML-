import java.util.Scanner;
public class Employee {
	 int id;
	String name;
	 int Phno;
	 static String desg;
	float salary;
    static int block;
    
    static{
    	desg="APSE";
    	block=1;
    	//System.out.println("static 1");
    	
    }
   /* Employee(  int id,String name,int Phno,float salary){
    	this.id=id;
    	this.name=name;
    	this.Phno=Phno;
    	this.salary=salary;
    	
    } */
    
    void create () {
    	Scanner sc = new Scanner(System.in);
    	
    	System.out.println("Give name of Employee"  );
    	name=sc.nextLine();
    	System.out.println("Give Phno of Employee"  );
    	Phno=sc.nextInt();
    	System.out.println("Give designation of Employee"  );
    	desg=sc.next();
    	System.out.println("Give salary of Employee" );
    	salary=sc.nextFloat();
    	
    	
    }
    
    void disp() {
    	System.out.println("The name of Employee"  +name);
    	System.out.println("The Phno of Employee"  +Phno);
    	System.out.println("The designation  of Employee"  +desg);
    	System.out.println("The salary of Employee"  +salary);
    	System.out.println("The block of Employee" +block);
    	System.out.println("The Id of Employee" +id);
    	
    	
    }

	public static void main(String[] args) {
		
		Employee e=new Employee();
		//Employee e1=new Employee(2,"mahesh",987997,25000.0f);
		//Employee e2=new Employee(3,"vishnu",9880657,25000.0f);
		
	e.create();
	e.disp();
	//.disp();
	//e2.disp();

	}

}
