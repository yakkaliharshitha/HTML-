
public class Reverse {

	public static void main(String[] args) {
		
			int x=1234;
			int n;
			
			for(int i=0;i<=3;i++) {
				n=x%10;
				System.out.println(n);	
				x=x/10;
			}
				       


	}

}
