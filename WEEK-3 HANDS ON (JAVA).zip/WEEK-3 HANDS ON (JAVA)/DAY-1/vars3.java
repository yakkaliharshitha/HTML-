
public class vars3 {

	        void accept(){
			int x=10;
			System.out.println("accept function");
			System.out.println(x);
			}
			void disp(){
			System.out.println("disp function");
			//System.out.println(x); error x is local to accept function

			}

			public static void main(String[] args) {
            vars3 t1 = new vars3();
			t1.accept();
			t1.disp();
			
			


			}
}

