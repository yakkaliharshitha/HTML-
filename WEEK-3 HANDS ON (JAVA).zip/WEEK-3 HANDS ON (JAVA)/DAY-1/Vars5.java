
public class Vars5 {

	
		
			static int x=50;
			int p=50;

			public static void main(String[] args) {
			/* TypesOfVars t=new TypesOfVars();
			System.out.println(t.p);
			*/
			int y=10;
			System.out.println(y);
			System.out.println(x);
			//System.out.println(p); error
			}
			


	}


