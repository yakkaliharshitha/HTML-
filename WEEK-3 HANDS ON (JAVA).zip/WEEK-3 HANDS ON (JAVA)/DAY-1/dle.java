class MyFirstJavaProg{

public static void main(String vars[]){

//float x=10.5; error

float x=(float)10.5;
float y=10.5f;


double a=10.5;
float b=(float)a;

System.out.println(x);
System.out.println(y);
System.out.println(b);

}
}
