
public class Vars2 {

	
		

			void accept(){
			System.out.println("accept function");
			}
			void disp(){
			System.out.println("disp function");
			}

			public static void main(String[] args) {

			Vars2 t=new Vars2();
			t.accept();
			t.disp();
			
			


	}

}
