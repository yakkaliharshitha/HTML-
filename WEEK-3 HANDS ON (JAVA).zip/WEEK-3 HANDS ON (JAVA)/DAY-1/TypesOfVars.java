
public class TypesOfVars {

	public static void main(String[] args) {

 System.out.println("Hello World");
 String x="123";
 int y=Integer.parseInt(x);
 System.out.println(y);
	}

}
