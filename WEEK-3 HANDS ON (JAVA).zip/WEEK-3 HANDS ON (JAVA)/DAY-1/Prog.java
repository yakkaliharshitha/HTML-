class myfstjava
{
public static void main(String arguments[]){
System.out.println("Hello World");
}
}