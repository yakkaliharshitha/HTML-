class MyFirstJavaProg{

public static void main(String vars[]){

String a="124HELLO";
int b=Integer.parseInt(a);
System.out.println(b);

}
}