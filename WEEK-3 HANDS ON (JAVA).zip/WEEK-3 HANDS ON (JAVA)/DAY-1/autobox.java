class MyFirstJavaProg{

public static void main(String vars[]){

int aa=1784;

//Integer cc=new Integer(aa);
// boxing

Integer cc=aa;
System.out.println(aa);
//auto boxing

}
}