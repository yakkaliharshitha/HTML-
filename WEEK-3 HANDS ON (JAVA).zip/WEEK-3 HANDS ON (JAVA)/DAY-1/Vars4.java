
public class Vars4 {

	

		int x;
		void accept(){
		System.out.println("accept function");
		System.out.println(x);
		}
		void disp(){
		System.out.println("disp function");
		System.out.println(x);
		}

		
		
	public static void main(String[] args) {
		
		Vars4 t=new Vars4();
		Vars4 t1=new Vars4();

		t.x=10;

		System.out.println("t x "+t.x);
		System.out.println("t1 x "+t1.x);
		}
		}
	

	


