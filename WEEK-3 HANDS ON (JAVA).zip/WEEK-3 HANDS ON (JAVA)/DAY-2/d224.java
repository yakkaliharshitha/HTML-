
public class d224 {

	

		public static void main(String[] args) {

		char alpha='w'; // 2 byte //int 4 byte

		switch (alpha) {
		case 'A' : System.out.println("vowel A");
		break;
		case 'E' : System.out.println("vowel E");
		break;
		case 'I' : System.out.println("vowel I");
		break;
		case 'O' : System.out.println("vowel O");
		break;
		case 'U' : System.out.println("vowel U");
		break;
		default:System.out.println("not a vowel ");

		}
		}
		}
		// is vowel ?  a e i o u 

