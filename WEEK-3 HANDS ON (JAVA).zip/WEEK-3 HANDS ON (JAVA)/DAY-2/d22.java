
public class d22 {
	
	

		static int x;
		void disp(){
		System.out.println(x);
		}
		static void disp2(){
		System.out.println(x);
		}
		public static void main(String[] args) {
		d22 d=new d22();
		d.disp();
		disp2();
		}
		}


