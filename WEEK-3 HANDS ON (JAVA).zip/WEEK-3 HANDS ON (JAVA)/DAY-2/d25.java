
public class d25 {
	

		public static void main(String[] args) {

		int x=10;
		int y= x++; // 1) y=x; 2)x+1

		y=++x; // 1)x+1 2)y=x;

		System.out.println(y);
		}

		}



