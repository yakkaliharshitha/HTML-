
public class d225 {


		int x;
		void myMeth(){
		int x=50;
		System.out.println(x);
		}

		void disp(){
		System.out.println(x);
		}

		public static void main(String[] args) {
		d225 d= new d225();
		d.myMeth();
		d.disp();
		}

		}


