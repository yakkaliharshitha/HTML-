
public class d24 {
	
	

		static int x=10;
		static int y=52;
		public static void main(String[] args) {

		//int y+=x ; error y is local var dont have a def value
		 y+=x;

		System.out.println(y);
		}

		}



