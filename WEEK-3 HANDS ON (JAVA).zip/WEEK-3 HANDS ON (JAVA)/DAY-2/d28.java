
public class d28 {
	
		int x;
		void init(){
		x=50;
		}
		void disp(){
		System.out.println(x);
		}
		public static void main(String[] args) {
		d28 d=new d28();
		d.disp();
		}
		}


