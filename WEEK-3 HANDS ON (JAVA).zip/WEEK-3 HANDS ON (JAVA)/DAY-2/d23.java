
public class d23 {

	

		static int x;
		void disp(){
		System.out.println("disp");
		System.out.println(x);
		}
		static void disp2(){
		System.out.println(x);
		}

		void abc()
		{
		System.out.println("abc");
		disp();
		}

		public static void main(String[] args) {
		d23 d=new d23();

		d.abc();

		}
		}


