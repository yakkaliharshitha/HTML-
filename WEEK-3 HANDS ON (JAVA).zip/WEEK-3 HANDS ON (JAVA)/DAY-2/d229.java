
public class d229 {
	
		int x;

		d229()//  constructor -. to initilize data members
		{
		x=50;
		}

		void disp(){
		System.out.println(x);
		}

		public static void main(String[] args) {
		d229 d=new d229(); // constructor is also used to create obj
		d.disp();

		}

		}


