
public class d223 {
	

		public static void main(String[] args) {

		int x=10;

		if(x>=10)
		{
		System.out.println("true");
		System.out.println("equal or greater");
		}
		else{
		System.out.println("false");
		System.out.println("neither equal  nor greater");
		}

		}
		}



