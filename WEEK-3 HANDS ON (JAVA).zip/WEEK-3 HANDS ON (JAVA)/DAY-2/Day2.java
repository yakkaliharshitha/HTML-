class Employee{
		int empId;
		String empName;

		void init(int empId,String empName){
		this.empId=empId;
		this.empName=empName;
		}

		/*
		void init(int eid,String ename){
		empId=eid;
		empName=ename;
		}
		*/
		void disp() {
		System.out.println(empId + " "+empName);
		}

		}
public class Day2 {

		public static void main(String[] args) {

		Employee employee1=new Employee();
		employee1.init(1,"RAJ");

		Employee employee2=new Employee();
		employee2.init(2,"RAJA");

		Employee employee3=new Employee();
		employee3.init(3,"RAJU");

		Employee employee4=new Employee();
		employee4.init(4,"RAJESH");


		employee1.disp();
		employee2.disp();
		employee3.disp();
		employee4.disp();


		}

		}






