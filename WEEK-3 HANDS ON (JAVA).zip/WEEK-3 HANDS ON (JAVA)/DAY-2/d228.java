
public class d228 {
	
		int x;

		void init(){
		x=50;
		}

		void disp(){
		System.out.println(x);
		}


		public static void main(String[] args) {
		d228 d=new d228();
		d.disp();
		d.init();

		}

		}



