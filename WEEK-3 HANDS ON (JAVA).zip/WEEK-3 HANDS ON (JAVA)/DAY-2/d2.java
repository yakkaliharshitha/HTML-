
public class d2 {
	
		public static void main(String[] args) {

		System.out.println("hello world ");

		//System.out.println(args[0]+args[1]);


		}
		}
		/*

		package-> group of related classes (folder)
		access specifier

		public
		protected
		default
		private

		JVM-software

		*/



