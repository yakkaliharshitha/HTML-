
public class d221 {
	
		int x;
		void init(){
		x=50;
		}
		void disp(){
		System.out.println(x);
		x=60;
		}
		public static void main(String[] args) {
		d221 d=new d221();// d.x=0;
		d221 d1=new d221();//d1.x=0;
		d.init();// d.x=50;
		d1.disp();// print d1.x


		}
		}



