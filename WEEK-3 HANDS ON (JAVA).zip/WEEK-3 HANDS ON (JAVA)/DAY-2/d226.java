
public class d226 {
	
	

		int x=100;
		void myMeth(){
		int x=50;
		System.out.println(x);//loc var
		System.out.println(this.x);//instance x .. this refers to current object
		}

		public static void main(String[] args) {
		d226 d= new d226();
		d.myMeth();
		//System.out.println(d.x);

		}

		}


