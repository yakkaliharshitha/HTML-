
public class d21 {

	

		int x;
		void disp(){
		System.out.println(x);
		}
		static void disp2()
		{
		//System.out.println(x); error cannot access no static
		//var in static function without an object ref
		}
		public static void main(String[] args) {
		d21 d=new d21();
		d.disp();


		}
		}


