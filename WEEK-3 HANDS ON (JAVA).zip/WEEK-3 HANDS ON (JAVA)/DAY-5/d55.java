
public class d55 {
	// A A -> 65 65
	// a a -> 97 97


	// a A ->  97 65


	// A a  -> 65 97


	// 65 , 66 , 67
	//97 ,98 ,99

	// 97 -32 =65
	// a - 32 =A

	// 65 +32 =97
	// A  + 32 =a


	boolean charEqual(char c1,char c2)
	{
	if(c1==c2 || c1==(c2-32) || c1==(c2+32))
	return true;

	else
	return false;
	}


	public static void main(String[] args) {
	System.out.println(new d55().charEqual('B', 'b'));
	System.out.println(new d55().charEqual('b', 'b'));
	System.out.println(new d55().charEqual('B', 'B'));
	System.out.println(new d55().charEqual('b', 'B'));
	}

}
