
public class d54 {
	

		public static void main(String[] args) {

		Object[] obj=new Object[5];

		obj[0]="Hello";
		obj[1]=10;
		obj[2]=10.5f;

		obj[3]=new d54();

		for(Object o:obj)
		{
		System.out.println(o);
		}
		}
		}



