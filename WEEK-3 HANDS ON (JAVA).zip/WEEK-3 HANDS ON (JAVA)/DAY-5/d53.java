
public class d53{
	String data;
	d53(String data){
	this.data=data;
	}
	void test(){
	System.out.println(data);
	}
	public static void main(String[] args) {


	d53[] d=new d53[5];

	d[0]=new d53("Hello World");
	d[0].test();


	d[1]=new d53("My data");
	d[1].test();

	d[2]=new d53(d[1].data);


	d[2].test();
	d[1].data="shdgjsgdah";
	d[2].test();

	
	}
}


