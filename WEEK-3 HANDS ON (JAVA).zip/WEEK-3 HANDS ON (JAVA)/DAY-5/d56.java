
public class d56 {
	//call the const of current class
	//Constructor call must be the first statement in a constructor


	public d56() {
	System.out.println("def const");
	}

	public d56(int x) {
	this();
	System.out.println("args const ");
	}

	public static void main(String[] args) {
	d56 d=new d56();

	}
	}




