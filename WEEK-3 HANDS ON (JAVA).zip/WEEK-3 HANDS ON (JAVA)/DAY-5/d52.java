
public class d52 {
	
		String data;
		d52(String data){
		this.data=data;
		}
		void test(){
		System.out.println(data);
		}
		public static void main(String[] args) {
		d52[] d=new d52[5];

		d[0]=new d52("Hello World");
		d[0].test();


		d[1]=new d52("My data");
		d[1].test();

		d[2]=d[1];
		d[2].test();


		d[2].data="THINK DIFFERENT";
		d[2].test();  
		d[1].test();

		//  My data different memory for d1 and d2

		// THINK DIFFERENT --> d2 > refs d1

		}
		}


