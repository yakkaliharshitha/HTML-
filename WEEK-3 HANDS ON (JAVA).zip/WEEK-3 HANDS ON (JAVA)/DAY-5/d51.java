
public class d51 {

	
	

		void test(){
		System.out.println("test data");
		}

		public static void main(String[] args) {

		d51[] d=new d51[5];//Array of type Day5 by def it contains null elements
		d[0]=new d51();
		d[0].test();

		d[1].test();

		}
		}
		// String[] x=new String[4];
		//x[0]=new String("hello");
		// x[0].toUppper();


