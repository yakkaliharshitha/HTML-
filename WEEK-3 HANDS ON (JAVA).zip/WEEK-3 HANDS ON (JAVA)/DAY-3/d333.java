
public class d333 {

	

		public static void main(String[] args) {

		int x=11;

		while(x<12)

		{
		x--;
		System.out.println(x);
		x=x+2;
		}
		System.out.println("done");

		}
		}


