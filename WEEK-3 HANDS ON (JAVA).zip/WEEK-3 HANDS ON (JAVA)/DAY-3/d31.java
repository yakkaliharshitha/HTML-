
public class d31 {
	
	    int x;
		void init(){
		int x=20;
		System.out.println(this.x);
		}

		public static void main(String[] args) {
		d31 d1=new d31();
		//d1.x=0;
		d31 d2=new d31();
		//d2.x=0;

		d1.x=50;
		d2.x=60;

		d1.init();
		}
		}


