
public class d33 {
	int x;
		d33()//  constructor -. to initilize data members
		{
		x=50;
		System.out.println("test const");
		}
		void disp(){
		x=60;
		System.out.println(x);
		}
		void disp1(){
		System.out.println("THIS IS DISP1");
		System.out.println("value of x in d1 "+x);
		}
		public static void main(String[] args) {
		d33 d=new d33(); // constructor is also used to create obj
		d.disp();
		d.disp1();

		System.out.println("-----------------------------------------");

		new d33().disp(); //Day2Last() x=50 ->disp() x=60 print x(60)
		new d33().disp1();//Day2Last() x=50 ->disp1() this is disp1 print x(50)
		}

		}



