
public class d332 {
	
   public static void main(String[] args) {
		int i=0;
		int ctr=0;
		for(i=1;i<10;){
		ctr++;
		System.out.println("test"+i);
		i=i+2;
		}

		System.out.println(ctr);
		}

		}




