
public class d336 {
	
	

		public static void main(String[] args) {

		int ctr=0;
		for(int i=0;i<10;i++)
		{

		for(int j=0;j<4;j++){
		ctr++;
		}

		}

		System.out.println(ctr);
		}
		}



