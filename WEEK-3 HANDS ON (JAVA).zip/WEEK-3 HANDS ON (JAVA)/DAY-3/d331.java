
public class d331 {
	
	 public static void main(String[] args) {

		int ctr=0;
		for(int i=0;i<10;i++)
		{
		ctr++;
		System.out.println("test"+i);
		}

		System.out.println(ctr);
		}

		}


