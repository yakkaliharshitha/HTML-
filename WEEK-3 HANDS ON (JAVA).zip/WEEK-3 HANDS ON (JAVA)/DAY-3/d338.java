
public class d338 {
	
	
		public static void main(String[] args) {

		//int ctr=0;
		int j;
		MyOuter:
		for(int i=0;i<10;i++)
		{
		MyInner:
		for(j=0;j<4;j++){

		if(i==5 && j==1)
		break MyOuter;
		System.out.println(i+" "+j);

		}




		}

		//System.out.println(ctr);
		}

}
