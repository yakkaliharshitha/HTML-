
public class d334 {
	

		public static void main(String[] args) {
		/*
		int x=12;
		do{
		x--;
		System.out.println(x);
		}
		while(x<12);
		*/

		int y=12;
		while(y<12)
		{
		y--;
		System.out.println(y);
		}

		System.out.println("done");

		}
		}


