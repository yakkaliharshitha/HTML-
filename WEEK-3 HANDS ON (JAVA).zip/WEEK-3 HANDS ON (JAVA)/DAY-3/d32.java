
public class d32 {
     	int x;
		void init(){
		int x=20;
		System.out.println(this.x);
		}

		/*
		static void init(){
		int x=20;
		System.out.println(this.x);
		}
		*/

		public static void main(String[] args) {
		d32 t1=new d32();
		//t1.x=0;
		d32 t2=new d32();
		//t2.x=0;

		t1.x=50;
		t2.x=60;

		t1.init();
		}
		}


