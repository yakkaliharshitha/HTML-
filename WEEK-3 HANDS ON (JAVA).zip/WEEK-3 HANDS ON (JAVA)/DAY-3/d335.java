
public class d335 {
	
	

		public static void main(String[] args) {

		boolean x=false;
		do{

		System.out.println("do while "+x);
		}
		while(x);


		while(x)
		{
		System.out.println("while "+x);
		}


		}
		}



