
public class d36 {
		String name;

		d36(int x){
		name="new name";
		}
		void disp(){
		System.out.println(name);
		}
		
	
		public static void main(String[] args) {
		d36 student=new d36(9);//error
		student.disp();
		}
		}

