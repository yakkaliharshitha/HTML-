
public class d38 {
	     int x;
		static int y;
		public d38() {
		x=50;
		y=60;
		}

		public static void main(String[] args) {

		System.out.println(y);

		d38 d=new d38();
		System.out.println(d.x);

		// const gets called when obj is created
		// static exists before object

		}

		}


