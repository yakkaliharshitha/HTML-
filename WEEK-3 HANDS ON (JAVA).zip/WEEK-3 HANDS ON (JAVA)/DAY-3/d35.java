
public class d35 {
	
		String name;
		d35(){
		name="some name";
		}
		d35(int x){
		name="new name";
		}
		void disp(){
		System.out.println(name);
		}
		
		
		public static void main(String[] args) {
		d35 student=new d35((int)10.5f);
		student.disp();
		}
		}


