
public class d339 {
	// collection of elements of same type

	

	static int[] marks;

	static int[] marks1=new int[3];
	public static void main(String[] args) {

	System.out.println(marks);
	System.out.println(marks[5]);
	//no memory is given to array ->NullPointer

	System.out.println(marks1[4]);
	//no memory is given to element at index 4 ->ArrayIndex
	}
	}
	//0
	//ArrayOutOfBOundsException -> when u try to access an element which is beyond the size of an array
	//nullPointerException



