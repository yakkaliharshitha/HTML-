
public class d34 {
		int x;
		d34()//  constructor -. to initilize data members
		{
		x=50;
		System.out.println("test const");
		}
		void disp(){
		x=60;
		System.out.println(x);
		}
		void disp1(){
		System.out.println("THIS IS DISP1");
		System.out.println("value of x in d1 "+x);
		}
		public static void main(String[] args) {
	    d34 d=new d34(); // constructor is also used to create obj
		d.disp();
		d.disp1();

		System.out.println("-----------------------------------------");

		new d34().disp(); //Day2Last() x=50 ->disp() x=60 print x(60)
		new d34().disp1();//Day2Last() x=50 ->disp1() this is disp1 print x(50)

		System.out.println("---- above is same as----------------------");

		d34 d1=new d34(); //x=50 print test const
		d1.disp(); // x=60 print x(60)
		d34 d2=new d34(); //x=50 print test const
		d2.disp1(); // print this is disp 1 value of x(50)



		}

		}


