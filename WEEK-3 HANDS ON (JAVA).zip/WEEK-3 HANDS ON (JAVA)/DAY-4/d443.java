
public class d443 {
	    String[][] data={{"Apple","Mango","Banana"},
		{"Cat","Dog"},{"Java","Python","c","c++"}};



		public void printData(String opt)
		{
		if(opt.equalsIgnoreCase("Fruits"))
		{
		for(String fruits:data[0])
		System.out.println(fruits);
		}
		else if(opt.equalsIgnoreCase("Animals"))
		{
		for(String fruits:data[1])
		System.out.println(fruits);
		}
		else if(opt.equalsIgnoreCase("Languages"))
		{
		for(String fruits:data[2])
		System.out.println(fruits);


		}
		else
		{
		System.out.println("invalid option selected");
		}

		}


		public static void main(String[] args) {
		d443 loop=new d443();
		loop.printData("ANImals");

		}
		}




