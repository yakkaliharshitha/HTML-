
public class d41 {
	


		public static void main(String[] args) {

		int[] x={1,2,4,8,9};
		int[] y=new int[5];
		int[] z=new int[]{5,6,8,7};




		System.out.println(z[3]);


		}
		}

