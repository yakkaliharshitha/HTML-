
public class d442 {
	


		public static void main(String[] args) {

		//String[] type={"Fruits","Animals","Languages"};
		/*
		for(String opt:type)
		{
		System.out.println(opt);
		}
		*/



		String[][] data={{"Apple","Mango","Banana"},
		{"Cat","Dog"},{"Java","Python","c","c++"}};


		for(int i=0;i<data.length;i++){

		for(int j=0;j<data[i].length;j++){
		System.out.print(data[i][j]+" ");

		}
		System.out.println();
		}

		System.out.println("------------------------------");
		for(String[] a:data)
		{

		for(String b:a)
		{
		System.out.print(b+" ");
		}
		System.out.println();
		}


		}
		}



