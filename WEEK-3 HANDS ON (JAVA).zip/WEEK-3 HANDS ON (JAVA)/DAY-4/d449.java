
public class d449 {
	

		public static void main(String[] args) {

		String str="test data";
		String a=str.toUpperCase();

		System.out.println(a);

		String newstr=str.replace('t', 'w');


		System.out.println(newstr);
		String newstr1=str.replaceFirst("t", "w");
		System.out.println(newstr1);

		}

		}



