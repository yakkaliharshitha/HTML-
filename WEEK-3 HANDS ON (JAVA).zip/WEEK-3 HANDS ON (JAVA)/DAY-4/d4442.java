import javax.swing.JFrame;
import javax.swing.JOptionPane;
public class d4442 {
	


	void sum(int x,int y){
	System.out.println(x+y);
	}

	int add(int x,int y){
	return x+y;
	}

	public static void main(String[] args) {

	d4442 m=new d4442();
	m.sum(10,50); //sum and prints on cmd

	int x=m.add(10,50);// get d sum do whatever u want
	System.out.println(x);
	JOptionPane.showMessageDialog(new JFrame(), x);

	System.out.println(x/2);
	}

	}

	//access specifier
	//access modifier
	//return type --> void , any premitive type any class type
	//name
	//args list
	//method body



