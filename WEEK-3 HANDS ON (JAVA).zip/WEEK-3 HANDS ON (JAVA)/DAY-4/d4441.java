
public class d4441 {

	

		public static void main(String[] args) {

		String str="test data";

		char[] arr=str.toCharArray();

		for(int i=0;i<str.length();i++)
		{
		if(arr[i]=='a')
		arr[i]='@';
		}


		String manStr=new String(arr);
		System.out.println(manStr);



		}

		}


