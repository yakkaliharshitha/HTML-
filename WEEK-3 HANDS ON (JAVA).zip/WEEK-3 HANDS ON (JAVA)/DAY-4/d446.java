
public class d446 {
	
      public static void main(String[] args) {

		String a="Hello";
		a.concat("World");

		System.out.println(a);

		String b="Hello";
		b=b.concat("World");
		System.out.println(b);


		}

		}




