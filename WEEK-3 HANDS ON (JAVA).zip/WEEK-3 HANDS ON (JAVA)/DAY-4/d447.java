
public class d447 {
	
       public static void main(String[] args) {

		StringBuffer sb=new StringBuffer("Hello");

		sb.append("World");
		System.out.println(sb);

		}

		}



