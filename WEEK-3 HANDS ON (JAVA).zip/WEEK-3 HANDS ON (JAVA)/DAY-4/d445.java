
public class d445 {
	public static void main(String[] args) {

		String x="Hello";
		String y="Hello";

		if(x==y)
		System.out.println("equal");
		else
		System.out.println("not equal");

		String a=new String("Hello");
		String b=new String("Hello");

		if(a==b)
		System.out.println("equal");
		else
		System.out.println("not equal");

		//password  -pass
		//confirm password -pass
		if(a.equals(b))
		System.out.println("equal");
		else
		System.out.println("not equal");



		}

		}


