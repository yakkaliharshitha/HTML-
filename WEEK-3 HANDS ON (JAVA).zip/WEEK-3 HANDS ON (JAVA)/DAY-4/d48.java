
public class d48 {
	public static void main(String[] args) {


		int[][] marks=new int[3][50];

		System.out.println(marks.length);

		System.out.println(marks[0].length);
		System.out.println(marks[1].length);
		System.out.println(marks[2].length);


		System.out.println(marks[0][20]);


		}
		}



