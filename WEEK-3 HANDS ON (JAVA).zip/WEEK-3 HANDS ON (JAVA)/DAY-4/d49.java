
public class d49 {
	public static void main(String[] args) {


		int[][] marks=new int[3][];

		marks[0]=new int[50];
		marks[1]=new int[20];
		marks[2]=new int[20];

		System.out.println(marks[0].length);
		System.out.println(marks[1].length);
		System.out.println(marks[2].length);

		}
		}


