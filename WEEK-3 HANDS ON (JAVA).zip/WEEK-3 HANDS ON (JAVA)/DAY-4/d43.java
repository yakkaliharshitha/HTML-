
public class d43 {

	 public static void main(String[] args) {

		int[] x={4,5,8,7,8};

		/*for(int i=0;i<x.length;i++)
		{
		System.out.println(x[i]);
		}
		*/


		for(int a:x){
		//if(a%2==0)
		System.out.println(a);
		}


}
}