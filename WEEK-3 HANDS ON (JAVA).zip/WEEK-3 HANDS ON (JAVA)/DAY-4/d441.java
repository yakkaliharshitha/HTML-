
public class d441 {
	
	public static void main(String[] args) {
       String[] type=new String[3];
		type[0]="Fruits";
		type[1]="Animals";
		type[2]="Languages";


		}
		}


