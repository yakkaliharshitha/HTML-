import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, NgModel } from '@angular/forms';
import { MycompComponent } from './mycomp/mycomp.component';
import { PipesdemoComponent } from './pipesdemo/pipesdemo.component';


@NgModule({
  declarations: [
    AppComponent,
    MycompComponent,
    PipesdemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
