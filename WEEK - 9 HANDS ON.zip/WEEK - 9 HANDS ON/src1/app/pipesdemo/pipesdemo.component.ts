import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipesdemo',
  templateUrl: './pipesdemo.component.html',
  styleUrls: ['./pipesdemo.component.css']
})
export class PipesdemoComponent implements OnInit {

  name="John Cena";

  now=new Date();


  
  constructor() { }

  ngOnInit() {
  }

disp()
{

console.log(this.name);
console.log(this.now);
}

}


