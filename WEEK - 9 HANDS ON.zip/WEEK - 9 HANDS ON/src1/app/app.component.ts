import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
   templateUrl: './app.component.html',
 //template:`<div> HELLO TEMPLATE  </div> 
 //<br> TESTING YOU`, 
   styleUrls: ['./app.component.css']
})



export class AppComponent {
  userCity="";
userState="";
userPhone="";

name;


  

 myFun()
 {
 
   console.log('test '+this.name);
 if(this.name=='John')
 {
   console.log(name);
 this.userCity="Mumbai";
 this.userState="Maharastra";
 this.userPhone="9988665544";
 
 }
 else if(this.name=='Rock')
 {
   console.log(this.name);
   this.userCity="Bangalore";
   this.userState="Karnataka";
   this.userPhone="9988777777";
   
 
 }
}
 
 
 }



  //size=50;
 // fruits=['apple','mango','banana','kiwi','dragon','orange'];











  // states=["maha","kar","ap"];
  // cities=[["pune","mumbai","sholapur","nasik"],["Bijapur","Hubli","Bangalore","Mysore"],["karnool","guntur","vijaywada"]];
  
  
  // selectedState;
  // fillCities:any[];
  
  // disp(){
  //   //alert(this.selectedState);
  // let idx= this.states.indexOf(this.selectedState);
  // this.fillCities=this.cities[idx];
  // }
  
  
  // }
  
//   a=true;
// b=true;


//   changeStatus():void{
//     if( this.isVisible)
//     this.isVisible=false;
//     else
//     this.isVisible=true;
//    }
   
  
// title = 'ANGULAR WORLD';

//   rollno=10;
//   clgId:number=60;
//   url;
//   n1=0;
//   n2=0;
// constructor()
// {
//   this.url=window.location.href;
//   this.title='new data';
// this.rollno=50;
// console.log(this.rollno);
// }



// hello():void
// {
//  alert(Number(this.n1) + Number(this.n2)); 
// }


// hello1():void
// {
//  alert(this.n1+this.n2); 
// }



// test():string{
//   return 'this is test function'
// }


// testCalc():number{
//   return 10+20;
// }

// testCalc1(n1:number,n2:number):number{
//   return n1+n2;
// }



// }


