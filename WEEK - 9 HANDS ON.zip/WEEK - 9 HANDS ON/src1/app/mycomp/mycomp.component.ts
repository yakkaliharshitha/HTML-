import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-mycomp',
  templateUrl: './mycomp.component.html',
  styleUrls: ['./mycomp.component.css']
})
export class MycompComponent implements OnInit {
  @Input('city')  city;
  @Input('state' )state;
  @Input('phone') phone;


   constructor() { }

//   @Input("name") name:string ;

// @Output() eveChild=new EventEmitter();
  ngOnInit() {
  }

// sendData()
// {
//   this.eveChild.emit('hello from child (MY COMP)');
// }  


}
