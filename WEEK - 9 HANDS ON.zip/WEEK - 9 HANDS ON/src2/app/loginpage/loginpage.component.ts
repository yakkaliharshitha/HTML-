import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {

  uname;
pass;
msg;

loginValidate()
{
  if(this.uname=="Abhi" && this.pass=="pass")
  {
  this.router.navigate(['home',this.uname,this.pass]);
  
}
  else
  {
    this.msg="user name or password invalid";
  }
}

  constructor(private router:Router) { }

  ngOnInit() {
  }

}