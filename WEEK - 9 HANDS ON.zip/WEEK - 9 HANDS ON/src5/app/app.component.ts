import { Component } from '@angular/core';
import { Patient } from 'src/patient.model';
import { PatientDaoService } from './patient-dao.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'restApiImpl';

constructor(private daosrv:PatientDaoService)
{

 
}
patients:Patient[]=[];
getPatients()
{

this.daosrv.getPatients().subscribe(
data=>this.patients=data,
error=>console.log(error)
);

for(let patient of this.patients)
{
  console.log(patient.patientName);
}
console.log('test');
}


patient:Patient={"patientId":0,"patientName":"","status":"" ,"age":0,"symptoms":""};

savePatient()
{

this.daosrv.savePatient(this.patient).subscribe(
data=>console.log(data),
error=>console.log(error)
);
}


getPatient()
{
  this.daosrv.getPatient(this.patient.patientId).subscribe(
data=>this.patient=data,
error=>console.log(error)

  );
}

deletePatient()
{
  this.daosrv.deletePatient(this.patient.patientId).subscribe(
data=>this.patient=data,
error=>console.log(error)

  );
}


updatePatient()
{

this.daosrv.updatePatient(this.patient).subscribe(
data=>console.log(data),
error=>console.log(error)
);
}



}