import { TestBed } from '@angular/core/testing';

import { PatientDaoService } from './patient-dao.service';

describe('PatientDaoService', () => {
  let service: PatientDaoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PatientDaoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
