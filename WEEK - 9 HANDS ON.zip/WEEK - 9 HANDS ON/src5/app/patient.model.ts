export class Patient
{
    patientId:number;
    patientName: string;
    status: string;
    age: number;
    symptoms:string;
}