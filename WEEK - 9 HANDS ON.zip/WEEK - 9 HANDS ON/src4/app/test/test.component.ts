import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  mydata;
  data1;
  add;
  reversing;
  high;
  constructor() { 
this.mydata= this.abc();

let abc1=() => {return 'any thing of ur choice'}
this.data1= abc1();

let xyz=(x:string):string=> {return x}

console.log(xyz('someargs'))

let ad1=(a:number,b:number):number=>{return a+b}
this.add=ad1(10,30)
//console.log(add1(10,20))


let rev1=(s:string):string=>{ return s.split('').reverse().join('');}
//console.log(rev1('hello'))
this.reversing=rev1('HIII ALL')
let high1=(x1:number,x2:number,x3:number):number =>{
  if((x1>x2)&&(x1>x3))
{
  return x1;

}
else if(x2>x3){
  return x2;
}
else{
  return x3;
}

}
//console.log(high1(20,100,60))
this.high=high1(89,90,600)

let converter= (dollar:number):number => {
  return dollar*75;
}

console.log(converter(1));


}




// xyy=function(ab){
// return ab;
// }


  ngOnInit() {
  }

abc()
{
  return 'hello world';
}

}
