import { Component } from '@angular/core';
import { MyserviceService } from './myservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mysrv';


  msg:string;
  
  
  
  constructor(private empsrv:MyserviceService)
  {
  
  }
  
  empId;
  empName;
  empTeam;
  
   addEmployee()
   {
    let emp={empId:'',name:'',team:''};
  
   emp.empId=this.empId;
   emp.name=this.empName;
   emp.team=this.empTeam;
   this.empsrv.addEmployee(emp); 
  
  }
  
  
  }




