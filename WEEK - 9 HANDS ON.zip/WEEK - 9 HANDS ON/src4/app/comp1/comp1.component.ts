import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  msg:string;
  mysrvc=new MyserviceService();
  
  employees:any[];
  

  
  getService()
  {
   this.employees= this.mysrvc.getEmployees();
  }
  


}




