import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor() { }


  employees=[
    {empId:1,name:'Virat',team:'RCB'},
    {empId:2,name:'Rohit',team:"MI"},
    {empId:3,name:'Rahul', team:"KP"}
  ]


  getEmployees()
  {
    return this.employees;
  }

  addEmployee(emp)
  {
    this.employees.push(emp);
  }

}



