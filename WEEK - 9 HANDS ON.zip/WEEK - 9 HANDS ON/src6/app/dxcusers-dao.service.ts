import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DxcUsers } from 'src/dxcusers.model';

@Injectable({
  providedIn: 'root'
})
export class DxcusersDaoService {
  constructor(private http:HttpClient) { 

  }

  getUers()
  {
  
    return this.http.get<DxcUsers[]>('http://localhost:2220/patients');
  
  }

saveUsers(dxcusers:DxcUsers)
{

 return this.http.post<any>('http://localhost:2220/regdata',dxcusers); 
}






}
  