import { Component } from '@angular/core';
import { DxcUsers } from 'src/dxcusers.model';
import { DxcusersDaoService } from './dxcusers-dao.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'UserRestApiImpl';



  constructor(private daosrv:DxcusersDaoService)
{

 
}
dxcuserss:DxcUsers[]=[];
getUsers()
{

this.daosrv.getUers().subscribe(
data=>this.dxcuserss=data,
error=>console.log(error)
);

for(let DxcUsers of this.dxcuserss)
{
  console.log(DxcUsers.username);
}
console.log('test');
}


dxcusers:DxcUsers={"userid":0,"username":"","password":"" ,"security_question": "","security_answer":""};

saveUser()
{

this.daosrv.saveUsers(this.dxcusers).subscribe(
data=>console.log(data),
error=>console.log(error)
);
}




}


