import { TestBed } from '@angular/core/testing';

import { DxcusersDaoService } from './dxcusers-dao.service';

describe('DxcusersDaoService', () => {
  let service: DxcusersDaoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DxcusersDaoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
