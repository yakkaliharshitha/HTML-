export class DxcUsers{


    userid:number;
    username: string;
    password: string;
    security_question:string;
    security_answer:string;


}