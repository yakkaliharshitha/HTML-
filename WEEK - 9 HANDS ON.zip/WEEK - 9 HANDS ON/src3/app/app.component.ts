import { Component } from '@angular/core';
import { Student } from 'src/student.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mypipe';
  students:any[];
  student=new Student();
  
  constructor()
  {
  
    this.students=this.student.getStudents();
  }
  



}
