import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GenderPipe } from 'src/gender.pipe';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ServicesComponent } from './services/services.component';
import { LaundryComponent } from './services/laundry/laundry.component';
import { CateringComponent } from './services/catering/catering.component';

@NgModule({
  declarations: [
    AppComponent,
     GenderPipe,
     ContactusComponent,
     AboutusComponent,
     ServicesComponent,
     LaundryComponent,
     CateringComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
