import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { CateringComponent } from './services/catering/catering.component';
import { LaundryComponent } from './services/laundry/laundry.component';
import { ServicesComponent } from './services/services.component';

const routes: Routes = [

{path:'contact',component:ContactusComponent},
{path:'about',component:AboutusComponent},
{ 
  path:'ourservice',component:ServicesComponent,
children:[
  {path:'ourservice/laundry',component:LaundryComponent},
 {path:'ourservice/catering',component:CateringComponent}
]
}


];




@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
