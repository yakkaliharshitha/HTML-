export class Student{    
    students:any[]
    constructor(){
    this.students=[
    {studentId:1,studentName:'raj',studentGender:'Male'},
    {studentId:2,studentName:'rajeev',studentGender:'male'},
    {studentId:3,studentName:'rajni',studentGender:'female'},
    {studentId:4,studentName:'rajeshwari',studentGender:'female'},
    {studentId:5,studentName:'harshu',studentGender:'feMale'},
    {studentId:6,studentName:'Abhi',studentGender:'male'},
    {studentId:7,studentName:'Ramu',studentGender:'male'},
    {studentId:8,studentName:'Sreenivasulu',studentGender:'male'}


    ]
    }
    getStudents()
    {
    return this.students;
    }
    }
    