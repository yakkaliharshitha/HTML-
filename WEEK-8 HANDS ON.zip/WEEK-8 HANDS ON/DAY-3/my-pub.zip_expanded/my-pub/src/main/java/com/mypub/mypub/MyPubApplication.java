package com.mypub.mypub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPubApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPubApplication.class, args);
	}

}
