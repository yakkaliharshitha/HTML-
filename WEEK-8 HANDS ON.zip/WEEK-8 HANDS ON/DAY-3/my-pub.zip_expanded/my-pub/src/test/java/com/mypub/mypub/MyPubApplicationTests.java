package com.mypub.mypub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyPubApplicationTests {

	@Test
	void contextLoads() {
	}

}
