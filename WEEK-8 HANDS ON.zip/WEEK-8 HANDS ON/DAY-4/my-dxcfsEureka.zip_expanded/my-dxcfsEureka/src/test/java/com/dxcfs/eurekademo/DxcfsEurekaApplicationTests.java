package com.dxcfs.eurekademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DxcfsEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
