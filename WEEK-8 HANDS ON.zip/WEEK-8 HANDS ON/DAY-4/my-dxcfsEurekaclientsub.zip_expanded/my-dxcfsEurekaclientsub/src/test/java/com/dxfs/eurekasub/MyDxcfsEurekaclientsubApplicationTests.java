package com.dxfs.eurekasub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyDxcfsEurekaclientsubApplicationTests {

	@Test
	void contextLoads() {
	}

}
