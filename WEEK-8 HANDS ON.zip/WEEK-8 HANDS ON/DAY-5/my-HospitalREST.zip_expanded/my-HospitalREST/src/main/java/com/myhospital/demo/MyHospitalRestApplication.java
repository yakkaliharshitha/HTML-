package com.myhospital.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyHospitalRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyHospitalRestApplication.class, args);
	}

}
