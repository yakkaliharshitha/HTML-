
public class SubStr3 {
	
	public static String mySubStr(String data)
	{
		int count=1;
		String d;
		d=data;
		char [] ch=data.toCharArray(); 
		
	for(int j=0;j<data.length();j++) {
		for(int k=j+1;k<data.length();k++) {
		if(ch[j]==ch[k] && ch[j]!=' ')  {
			count++;
			ch[k]='0';
			
		}
		}
	    if(count>1 && ch[j]!='0') {
			System.out.println(count +" "+ch[j]);
			break;
			}
		}

		return " ";
	}
	
	public static void main(String[] args) {
		mySubStr("helloall");

	}


}
