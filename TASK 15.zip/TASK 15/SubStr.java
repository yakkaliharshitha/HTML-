
public class SubStr {
	
	public static String mySubStr(String data,int index)
	{
		int a=index;
		String d;
		d=data;
		char [] ch=data.toCharArray(); 
		
		
		for(int j=a;j<data.length();j++) {
			System.out.print(ch[j] );
		}
		System.out.print("  " );
		
	
		
		return " ";
	}
	
	
	public static String mySubStr(String data,int index , int index2)
	{
		int a=index2;
		int b=index;
		String d;
		d=data;
		char [] ch=data.toCharArray(); 
		
		for(int j=0;j<b;j++) {
			System.out.print(ch[j]);
			}
		
			for(int k=a+b;k<data.length();k++) {
			System.out.print(ch[k] );
		}
			
		
	
		
		return " ";
	}
	

	public static void main(String[] args) {
		
		mySubStr("HELLO WORLD", 3);
		
	     mySubStr("HELLO WORLD", 2,3);

	}

}
