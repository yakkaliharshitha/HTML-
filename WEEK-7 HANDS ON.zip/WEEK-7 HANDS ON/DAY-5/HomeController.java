package com.spr.spr;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spr.spr.bean.Car;
import com.spr.spr.bean.ShowRoom;
import com.spr.spr.bean.Student;


@Controller
public class HomeController {


	private String shname;

	  @InitBinder public void initBinder(WebDataBinder binder) {
	 
	 
	  SimpleDateFormat dff=new SimpleDateFormat("yyyy-MM-dd");
	  binder.registerCustomEditor(Date.class, new CustomDateEditor(dff, false));
	  
	 }
	  
	  
	 @RequestMapping(value = "/") public String home() { return "home"; }
	 
	 
	 @RequestMapping(value="display") public String myMeth2(@ModelAttribute
	 Student student) {
	  
	 return "design"; }
	 









}