import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class d13SerClass2 {

public static void main(String[] args) {

// garbage collector : runs auto n cleans up d memory
try {

d13Student student=new d13Student(10, "YASHWANT", "AP");

FileOutputStream fout=new FileOutputStream("student.ser");

ObjectOutputStream ostr=new ObjectOutputStream(fout);
ostr.writeObject(student);

student=null;
//System.out.println(student.getAddress());
System.out.println("done");


} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

}

}




