import java.io.Serializable;

public class d13Student  implements Serializable{
private int rollNO;
private String name;
private String address;
public int getRollNO() {
return rollNO;
}
public void setRollNO(int rollNO) {
this.rollNO = rollNO;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public String getAddress() {
return address;
}
public void setAddress(String address) {
this.address = address;
}
public d13Student(int rollNO, String name, String address) {
super();
this.rollNO = rollNO;
this.name = name;
this.address = address;
}

public d13Student() {
// TODO Auto-generated constructor stub
}
@Override
public String toString() {
return "Student [rollNO=" + rollNO + ", name=" + name + ", address=" + address + "]";
}

}



