import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;

public class d13FileInput {


public static void main(String[] args) {
String thisline=null;
try {

FileReader rd=new FileReader("test.txt");
BufferedReader brd=new BufferedReader(rd);
while((thisline=brd.readLine()) !=null) {
System.out.println(thisline);
}
}
catch (FileNotFoundException e) {
e.printStackTrace();
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

}
}




