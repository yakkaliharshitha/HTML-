import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class d13DserDemo {


public static void main(String[] args) {


try {
FileInputStream fin=new FileInputStream("student.ser");
ObjectInputStream oin=new ObjectInputStream(fin);

d13Student stud=(d13Student)oin.readObject();

FileInputStream fin1=new FileInputStream("student2.ser");
ObjectInputStream oin2=new ObjectInputStream(fin1);

d13Student2 stud2=(d13Student2)oin2.readObject();


System.out.println(stud2);

} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}



}

}





