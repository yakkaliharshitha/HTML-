import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class d13FileOutput {


public static void main(String[] args) {

try {

FileOutputStream fout=new FileOutputStream("test.txt",true);

PrintStream ps=new PrintStream(fout);

ps.println("Ok");

System.out.println("DONE");

}
catch (FileNotFoundException e) {
e.printStackTrace();
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}
}



