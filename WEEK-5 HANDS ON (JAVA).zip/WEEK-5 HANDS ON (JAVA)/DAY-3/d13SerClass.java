import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class d13SerClass {


public static void main(String[] args) {

try {

d13Student student=new d13Student(10, "JOHN", "USA");
FileOutputStream fout=new FileOutputStream("student.ser");

ObjectOutputStream ostr=new ObjectOutputStream(fout);
ostr.writeObject(student);

d13Student2 student2=new d13Student2(9, "Harshu", "Delhi");
FileOutputStream fout1=new FileOutputStream("student2.ser");

ObjectOutputStream ostr1=new ObjectOutputStream(fout1);
ostr1.writeObject(student2);

System.out.println("done");


} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

}

}


