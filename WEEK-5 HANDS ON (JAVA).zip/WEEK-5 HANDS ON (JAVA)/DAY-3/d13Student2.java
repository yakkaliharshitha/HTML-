import java.io.Serializable;

public class d13Student2  implements Serializable{

private transient int rollNO;
private String name;
private String address;

private static int test;


public static int getTest() {
return test;
}
public static void setTest(int test) {
d13Student2.test = test;
}
public int getRollNO() {
return rollNO;
}
public void setRollNO(int rollNO) {
this.rollNO = rollNO;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public String getAddress() {
return address;
}
public void setAddress(String address) {
this.address = address;
}
public d13Student2(int rollNO, String name, String address) {
super();
this.rollNO = rollNO;
this.name = name;
this.address = address;
}

public d13Student2() {
// TODO Auto-generated constructor stub
}
@Override
public String toString() {
return "Student [rollNO=" + rollNO + ", name=" + name + ", address=" + address + "]";
}

}




