import java.util.Scanner;

public class d13Scanner {


public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("enter you salary");
float x= sc.nextFloat();
System.out.println(x);
System.out.println("enter you name");
String n= sc.next();
System.out.println(n);
System.out.println("enter you id");
int id= sc.nextInt();
System.out.println(id);
}
}



