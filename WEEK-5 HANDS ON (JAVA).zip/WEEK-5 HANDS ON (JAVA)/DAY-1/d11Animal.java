public abstract class d11Animal {

public abstract void move();
}



