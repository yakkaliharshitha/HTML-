public class d11Cat extends d11Animal{

@Override
public void move() {
System.out.println("CAT MOVE");
}



}

