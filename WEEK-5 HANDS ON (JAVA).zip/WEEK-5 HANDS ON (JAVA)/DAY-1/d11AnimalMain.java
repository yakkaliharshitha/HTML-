public class d11AnimalMain {
	
	public void animalMove(d11Cat c)
	{
	System.out.println("Moving the animal ");
	c.move();
	}




	
public static void main(String[] args) {
	
	d11Animal a=new d11Dog();
	a.move();
	//a.eat();
	//error cannot call child specific methods by refering to parents
	//ref variable


	/* Cat c=new Cat();
	c.move();
	c.eat();
	*/
	d11AnimalMain a1=new d11AnimalMain();

	d11Dog d= new d11Dog();
	d11Cat c= new d11Cat();

	a1.animalMove(c);


d11Animal a11=new d11Dog();
a11.move();// dynamic method dispatching

}

}

