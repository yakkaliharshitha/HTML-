
public class d11Dog extends d11Animal{


@Override
public void move() {
System.out.println("DOG MOVE");
}
}

