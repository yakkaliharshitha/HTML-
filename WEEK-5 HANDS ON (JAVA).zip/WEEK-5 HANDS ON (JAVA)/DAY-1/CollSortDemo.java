package pack1.sub;
import java.util.Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollSortDemo {


	public static void main(String[] args) {


		/*List<Book> books=new ArrayList<Book>();

		Book b1=new Book(5, " Test ","any thing");
		Book b2=new Book(23, " My Book","never know");
		Book b3=new Book(3, "The Book","dont know");
		Book b4=new Book(9, "Java","James");

		books.add(b1);
		books.add(b2);
		books.add(b3);
		books.add(b4);

		// Comparable -- compareTo  --logic for sorting

		Collections.sort(books);

		for(Book book:books)
		{
		System.out.println(book);

		}

		}}
*/

List<Integer> marks=new ArrayList<Integer>();


marks.add(56);
marks.add(66);
marks.add(65);
marks.add(80);
marks.add(77);
marks.add(69);

Collections.sort(marks);

for(int x:marks)
{
System.out.println(x);
}



}

}


