//extend Thread class
//implement Runnable Interface

//run--> thread body

//new --  when we create an object of thread
//runnable --- when we call start() ?
//--- not runnable --> sleeping , waiting or been blocked by other thread
//-- dead --> when it completes run method // assign a null value to thread obj


public class d12Thread1 implements Runnable{

@Override
public void run() {
for(int i=0;i<10;i++)
{
System.out.println("THREAD 1 CLASS "+Thread.currentThread().getName());

try {
Thread.sleep(1000);
} catch (InterruptedException e) {
e.printStackTrace();
}
}

}

}


class ThreadDemo implements Runnable{

@Override
public void run() {
for(int i=0;i<10;i++)
{
System.out.println("ThreadDemo1 CLASS "+Thread.currentThread().getName());

try {
Thread.sleep(1000);
} catch (InterruptedException e) {
e.printStackTrace();
}
}

}

public static void main(String[] args) {

ThreadDemo demo1=new ThreadDemo();
d12Thread1 thd1=new d12Thread1();


Thread t1=new Thread(demo1,"my thread");
Thread t2=new Thread(thd1,"new Thread");
t1.start();
t2.start();
// run run
}

}