//extend Thread class
//implement Runnable Interface

//run--> thread body

//new --  when we create an object of thread
//runnable --- when we call start() ?
//--- not runnable --> sleeping , waiting or been blocked by other thread
//-- dead --> when it completes run method // assign a null value to thread obj


public class d12RunnableInterface implements Runnable{

@Override
public void run() {
System.out.println(Thread.currentThread().getName());
}


public static void main(String[] args) {

 d12RunnableInterface demo1=new d12RunnableInterface ();

Thread t=new Thread(demo1,"my thread");
t.start();

}

}




