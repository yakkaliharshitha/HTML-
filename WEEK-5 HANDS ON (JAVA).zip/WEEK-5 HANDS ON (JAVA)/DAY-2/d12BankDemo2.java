class Account2
{
public synchronized void getMoney(){
for(int i=0;i<10;i++){
System.out.println(i+" "+Thread.currentThread().getName()+" WITHDRAWING MONEY");
try {
Thread.sleep(3000);
} catch (InterruptedException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}

System.out.println("DONE WITHDRAWING");
}

}


class AccountHolder1 implements Runnable{
Account2 account;
public AccountHolder1(Account2 account) {
this.account=account;
}
@Override
public void run() {

account.getMoney();
}
}

public class d12BankDemo2 {

public static void main(String[] args) {

Account2 icici007=new Account2();

Account2 iciciRajni=new Account2();


AccountHolder1 ATM1=new AccountHolder1(icici007);
AccountHolder1 ATM2=new AccountHolder1(iciciRajni);

Thread thd=new Thread(ATM1,"ATM1 icici007 ");
thd.start();

Thread thd1=new Thread(ATM2,"ATM2 iciciRAjni ");
thd1.start();



}



}

