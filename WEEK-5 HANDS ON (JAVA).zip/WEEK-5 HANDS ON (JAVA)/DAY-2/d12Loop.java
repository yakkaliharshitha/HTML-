class Thread11 implements Runnable{

@Override
public void run() {
for(int i=0;i<10;i++)
{
System.out.println("THREAD 1 CLASS "+Thread.currentThread().getName());

try {
Thread.sleep(1000);
} catch (InterruptedException e) {
e.printStackTrace();
}
}

}

}


public class d12Loop implements Runnable{

@Override
public void run() {
for(int i=0;i<10;i++)
{
System.out.println("ThreadDemo1 CLASS "+Thread.currentThread().getName());

try {
Thread.sleep(1000);
} catch (InterruptedException e) {
e.printStackTrace();
}
}

}

public static void main(String[] args) {

d12Loop demo1=new d12Loop();
Thread11 thd1=new Thread11();


Thread t1=new Thread(demo1,"my thread");
Thread t2=new Thread(thd1,"new Thread");
t1.start();
t2.start();
// run run
}

}


