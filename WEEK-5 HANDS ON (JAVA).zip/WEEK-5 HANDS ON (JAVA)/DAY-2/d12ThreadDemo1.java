//extend Thread class
//implement Runnable Interface

//run--> thread body

//new --  when we create an object of thread
//runnable --- when we call start() ?
//--- not runnable --> sleeping , waiting or been blocked by other thread
//-- dead --> when it completes run method // assign a null value to thread obj


public class d12ThreadDemo1  extends Thread{
@Override
public void run() {
System.out.println("run method");
System.out.println("run method "+Thread.currentThread().getName());
}
public static void main(String[] args) {
d12ThreadDemo1 td=new d12ThreadDemo1();
//td.start();// dead
//td.start();

td.run();
td.run();
td.run();


System.out.println("main method "+Thread.currentThread().getName());
}

}




