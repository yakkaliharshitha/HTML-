
//extend Thread class
//implement Runnable Interface

//run--> thread body

//new --  when we create an object of thread
//runnable --- when we call start() ?
//--- not runnable --> sleeping , waiting or been blocked by other thread
//-- dead --> when it completes run method // assign a null value to thread obj


public class d12NotRunnable extends Thread{
@Override
public void run() {

System.out.println("run method");
System.out.println("run method "+Thread.currentThread().getName());

for(int i=0;i<10;i++)
{
System.out.println(i);

try {
Thread.sleep(1000);
} catch (InterruptedException e) {

e.printStackTrace();
}
}
}
public static void main(String[] args) {
d12NotRunnable td=new d12NotRunnable();
td.start();

System.out.println("main method "+Thread.currentThread().getName());


}

}

 


