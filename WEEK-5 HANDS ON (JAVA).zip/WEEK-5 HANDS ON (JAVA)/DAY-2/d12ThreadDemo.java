//extend Thread class
//implement Runnable Interface

//run--> thread body

//new --  when we create an object of thread
//runnable --- when we call start() ?
//--- not runnable --> sleeping , waiting or been blocked by other thread
//-- dead --> when it completes run method // assign a null value to thread obj

public class d12ThreadDemo extends Thread{
@Override
public void run() {
System.out.println("run method");
System.out.println("run method "+Thread.currentThread().getName());
}
public static void main(String[] args) {
d12ThreadDemo td=new d12ThreadDemo();
td.start();
System.out.println("main method "+Thread.currentThread().getName());
}

}




