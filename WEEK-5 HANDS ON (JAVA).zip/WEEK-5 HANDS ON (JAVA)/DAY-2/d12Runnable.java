class Thread1 implements Runnable{

@Override
public void run() {
System.out.println("THREAD 1 CLASS "+Thread.currentThread().getName());
}
}


public class d12Runnable implements Runnable{

@Override
public void run() {
System.out.println(Thread.currentThread().getName());
}


public static void main(String[] args) {

d12Runnable demo1=new d12Runnable();
Thread1 thd1=new Thread1();


Thread t1=new Thread(demo1,"my thread");
Thread t2=new Thread(thd1,"new Thread");
t1.start();
t2.start();

}

}


