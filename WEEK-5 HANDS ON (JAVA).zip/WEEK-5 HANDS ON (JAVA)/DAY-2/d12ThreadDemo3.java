//extend Thread class
//implement Runnable Interface

//run--> thread body

//new --  when we create an object of thread
//runnable --- when we call start() ?
//--- not runnable --> sleeping , waiting or been blocked by other thread
//-- dead --> when it completes run method // assign a null value to thread obj





public class d12ThreadDemo3 implements Runnable{

@Override
public void run() {
System.out.println(Thread.currentThread().getName());
}


public static void main(String[] args) {

d12ThreadDemo3 demo1=new d12ThreadDemo3();

Thread t1=new Thread(demo1,"my thread");
Thread t2=new Thread(demo1,"new Thread");
t1.start();
t2.start();

}

}




