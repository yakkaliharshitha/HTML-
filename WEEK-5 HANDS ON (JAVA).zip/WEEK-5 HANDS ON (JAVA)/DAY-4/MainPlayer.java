package pack2;

public class MainPlayer {

public static void main(String[] args) {

Address address=new Address("MG ROAD");
Player p=new Player("MESSI", 34,address);

Player p1=null;
try{
p1=(Player)p.clone();
}
catch (Exception e) {
e.printStackTrace();
}

p1.setName("VIRAT");


System.out.println(p1.getName());// virat -- commercial street
System.out.println(p.getName()); //messi


p1.getAddress().setStreetName("Commercial Street");


System.out.println(p.getAddress().getStreetName());//M.G Road
System.out.println(p1.getAddress().getStreetName());//commercial street



}

}
