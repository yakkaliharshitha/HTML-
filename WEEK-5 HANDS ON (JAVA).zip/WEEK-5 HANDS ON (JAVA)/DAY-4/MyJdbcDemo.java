package MyJdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class MyJdbcDemo {

	public static void main(String[] args) {
	
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("loaded driver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dxcfs","pass");
			 String sql="insert into clg values('135','JTT','0')";

			 PreparedStatement stat=con.prepareStatement(sql);

			 stat.executeUpdate();

			System.out.println("Inserted");
			
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		
		

	}

}
