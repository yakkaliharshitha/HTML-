package pack2;

public class Address implements Cloneable{


String streetName;

public String getStreetName() {
return streetName;
}

public void setStreetName(String streetName) {
this.streetName = streetName;
}

public Address(String streetName) {
super();
this.streetName = streetName;
}

@Override
public String toString() {
return "Address [streetName=" + streetName + "]";
}


@Override
protected Object clone() throws CloneNotSupportedException {
return super.clone();
}

}

