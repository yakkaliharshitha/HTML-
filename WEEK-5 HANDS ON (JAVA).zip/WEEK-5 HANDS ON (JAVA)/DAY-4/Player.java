package pack2;

public class Player implements Cloneable{

String name;
int age;

Address address;

public Player(String name, int age, Address address) {
super();
this.name = name;
this.age = age;
this.address = address;
}
public Address getAddress() {
return address;
}
public void setAddress(Address address) {
this.address = address;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public int getAge() {
return age;
}
public void setAge(int age) {
this.age = age;
}
public Player(String name, int age) {
super();
this.name = name;
this.age = age;
}
@Override
public String toString() {
return "Player [name=" + name + ", age=" + age + "]";
}

//Object class method
@Override
protected Object clone() throws CloneNotSupportedException {

Player p=(Player)super.clone();
p.address=(Address)this.address.clone();
return p;

//return super.clone();
}

}