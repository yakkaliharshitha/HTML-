package myschool.service;
import java.util.ArrayList;

import myschool.dao.CollegeDao;
import myschool.model.College;

public class CollegeService {

public static void main(String[] args) {
	College college=new College();
	CollegeDao dao=new CollegeDao();
	college.setcName("Worst University");
	int res=dao.updateCollege(123, college);
	System.out.println(res);

	
	/*CollegeDao dao=new CollegeDao();
	System.out.println(dao.deleteCollegeById(222));
	*/

	
	/*CollegeDao dao=new CollegeDao();
	System.out.println(dao.getCollegeById(122));
	*/
/*
	CollegeDao dao=new CollegeDao();
	//System.out.println(dao.createCollege(college));


	ArrayList<College> collegeList= dao.getColleges();

	for(College clg:collegeList)
	{

	System.out.println(clg);
	}
*/
/*
College college=new College(222,"SOME CLG",0);

CollegeDao dao=new CollegeDao();
System.out.println(dao.createCollege(college));
*/

}

}



