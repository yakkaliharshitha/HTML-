package MyJdbcDemo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class d15InsertParameter {

public static void main(String[]args) {


try
{

Class.forName("oracle.jdbc.OracleDriver");

Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dxcfs","pass");

String sql="insert into clg values(?,?,?)";

PreparedStatement stat=con.prepareStatement(sql);
//Statement -> no prmtzd queries
//PreparedStatement -> prmtzd queries
//CallableStatement -> procs and named prmtzd queries



stat.setInt(1, 1054);
stat.setString(2, "PANJAB University");
stat.setInt(3, 0);


stat.executeUpdate();



// execute()  --> ddl
//ResultSet rs= executeQuery()--> dql (select)
//int executeUpdate() --> dml

System.out.println("inserted");
}
catch (Exception e) {
e.printStackTrace();
}
}

}
/*
  Driver --> loading d driver 4types jdbc-odbc
 
steps to add ojdbc6 lib to the project are

  ->right click on project
  ->select properties
  ->left panel select java build path
  ->right panel select library tab
  -> select add external jar
  -> select the jar file to be added
 
  Connect to db
 
  create n exe sql stats
  SQLExceptions handle
*/

