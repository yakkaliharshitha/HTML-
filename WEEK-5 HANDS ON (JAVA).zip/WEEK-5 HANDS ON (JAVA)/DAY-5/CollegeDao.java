package myschool.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import myschool.dbutil.DBConnection;
import myschool.model.College;

public class CollegeDao {
	public int updateCollege(int collegeId,College college){
		// 0 wrost university 0
		try
		{
		Connection connection=DBConnection.getConnect();

		College existingCollege= getCollegeById(collegeId);
		// 123 Best University 6

		String sql="update clg set cname=? ,no_of_stud=? where cid=?";
		PreparedStatement stat=connection.prepareStatement(sql);


		// 123 Best University 6

		if(college.getcName()!=null)
		{
		existingCollege.setcName(college.getcName());
		}
		// 123 Worst University 6


		if(college.getNoOfStud()!=0)
		{
		existingCollege.setNoOfStud((college.getNoOfStud()));
		}


		stat.setString(1, existingCollege.getcName());
		stat.setInt(2, existingCollege.getNoOfStud());
		stat.setInt(3, collegeId);



		int res= stat.executeUpdate();
		if(res>0){
		return res;
		}

		}
		catch (Exception e) {
		e.printStackTrace();

		}

		return 0;
		}

	public int deleteCollegeById(int collegeId){
		try
		{
		Connection connection=DBConnection.getConnect();

		String sql="delete from clg where cid=?";
		PreparedStatement stat=connection.prepareStatement(sql);


		stat.setInt(1, collegeId);

		int res= stat.executeUpdate();
		if(res>0){
		return res;
		}

		}
		catch (Exception e) {
		e.printStackTrace();

		}

		return 0;
		}


	
	
	public College getCollegeById(int collegeId){
		try
		{
		Connection connection=DBConnection.getConnect();

		String sql="select * from clg where cid=?";
		PreparedStatement stat=connection.prepareStatement(sql);


		stat.setInt(1, collegeId);

		ResultSet res= stat.executeQuery();
		if(res.next())
		{

		int clgId= res.getInt(1);
		String clgName= res.getString(2);
		int noOfStud= res.getInt(3);
		College college=new College(clgId, clgName, noOfStud);
		return college;

		}


		}
		catch (Exception e) {
		e.printStackTrace();

		}

		return null;
		}
	public ArrayList<College> getColleges(){
		try
		{
		Connection connection=DBConnection.getConnect();

		String sql="select * from clg";
		PreparedStatement stat=connection.prepareStatement(sql);

		ArrayList<College> collegeList=new ArrayList<>();

		ResultSet res= stat.executeQuery();
		if(res.next())
		{

		do{

		int clgId= res.getInt(1);
		String clgName= res.getString(2);
		int noOfStud= res.getInt(3);

		College college=new College(clgId, clgName, noOfStud);

		collegeList.add(college);

		 }
		while(res.next());

		}

		return collegeList;

		}
		catch (Exception e) {
		e.printStackTrace();

		}

		return null;
		}


public String createCollege(College college){
try //22 Some CLG 0
{
Connection connection=DBConnection.getConnect();

String sql="insert into clg values(?,?,?)";
PreparedStatement stat=connection.prepareStatement(sql);

stat.setInt(1, college.getcId());
stat.setString(2, college.getcName());
stat.setInt(3, college.getNoOfStud());

int res= stat.executeUpdate();
if(res>0)
return "College Created";
else
return "College connot be Created";
}
catch (Exception e) {
e.printStackTrace();
return "Exception "+e;
}


}

}

