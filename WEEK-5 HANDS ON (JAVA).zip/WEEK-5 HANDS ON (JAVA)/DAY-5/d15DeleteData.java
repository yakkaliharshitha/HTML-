package MyJdbcDemo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class d15DeleteData {

public static void main(String[] args) {

try {
Class.forName("oracle.jdbc.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dxcfs", "pass");

//con.setAutoCommit(false);
String sql="delete from clg where cid=?";

PreparedStatement stat=con.prepareStatement(sql);

Scanner sc=new Scanner(System.in);

stat.setInt(1, sc.nextInt());

int res= stat.executeUpdate();

if(res>0)
System.out.println("recs deleted");



}
catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (Exception e) {
e.printStackTrace();
}

}

}


