package MyJdbcDemo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class d15InsertScanner {

public static void main(String[] args) {

try
{

Class.forName("oracle.jdbc.OracleDriver");

Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dxcfs","pass");

String sql="insert into clg values(?,?,?)";

PreparedStatement stat=con.prepareStatement(sql);

Scanner sc=new Scanner(System.in);
System.out.println("ENTER Cid , clg name and no of studs");

int cId=sc.nextInt();
String cName=sc.next();
int nos=sc.nextInt();

stat.setInt(1, cId);
stat.setString(2, cName);
stat.setInt(3, nos);


stat.executeUpdate();

System.out.println("inserted");
}
catch (Exception e) {
e.printStackTrace();
}
}

}




