
public class Reversestr {
	
public static void main(String[] args) {
		  
		  String str="Helloworld";
		
	char[] arr=str.toCharArray();
		
	String reverse=" ";
	
	for(int i=str.length()-1;i>=0;i--){
	reverse+=arr[i];
	//System.out.println(reverse);
	
	}
	System.out.println(reverse);
	}
			
	
		

	}


