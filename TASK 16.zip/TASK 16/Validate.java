
public class Validate {
	
	String Validatestr(String str) {
	int count=0;
	
	char[] arr=str.toCharArray();
	
	for( int i=0;i<str.length();i++) {
		
		if(arr[i]>= 48 && arr[i]<=57) {
			count=count+1;
			}
		
	}
	if(count==10) {
		System.out.println("Valid");
	}
	
	else System.out.println("InValid");
	
	return " ";
	}

	public static void main(String[] args) {
		Validate v=new Validate();
		v.Validatestr("123456789111");
		

	}

}
