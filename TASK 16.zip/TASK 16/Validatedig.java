
public class Validatedig {
  String Validatedigit(String str) {
	  int a=str.length();
	int count=0;
	char[] arr=str.toCharArray();
	
	for( int i=0;i<str.length();i++) {
		
		if(arr[i]>= 48 && arr[i]<=57) {
			count=count+1;
		}
		}
	if(count>0) {
		System.out.println("Digits are present");
	}
	
	else System.out.println("No digits are present");
	
	return " ";
	}

	public static void main(String[] args) {
		Validatedig v=new Validatedig();
		v.Validatedigit("0978fytfgyfyf");
		

	}

}

