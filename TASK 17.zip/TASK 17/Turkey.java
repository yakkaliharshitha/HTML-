
public class Turkey extends country{
	@Override
	public boolean phoneNumberFormat(String number) {
		boolean t=true;
		boolean a=false;
		boolean m=true;
		boolean k=true;
		boolean n=true;
		boolean l=true;
		boolean o=true;
		int count=1;
		int count1=0;
	char[] arr=number.toCharArray();
		if(number.length()==14) {
			if(number.substring(0,4).contentEquals("+90 "))
			{
				//System.out.println("in equal");
				if(arr[7]=='-') {
					//System.out.println("-- true");
					t=true;
				}
				else t=false;
			
			for(int i=4;i<number.length();i++) {
		  if(arr[i]>='0' && arr[i]<='9') {
			 // System.out.println(arr[i]);
			// System.out.println(count);
			  count++;
				k=true;
		  }
			else  k=false;
				 }
			
			if(t && count==9) {
				l=true;
			}
			return l;
			
			}
		}
		else if(number.length()==12) {
			 if(number.substring(0,4).contentEquals("0509")) {
				if(arr[4]=='-'&& arr[8]=='-')
					m=true;
				else return m=false;
				for(int i=5;i<number.length();i++) {
					  if(arr[i]>='0' && arr[i]<='9') {
						  count1++;
							n=true;
					  }
						else  n=false;
							 }
				if(m && count1==6)
					o=true;
			     return o;
			} 
		}
			
			
				 else {
			
			System.out.println("Invalid Phone number format");
		    }
		return a;
		
	

	}
}

