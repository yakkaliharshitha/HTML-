

class Brazil extends country {
	@Override
	public boolean phoneNumberFormat(String number) {
		boolean t=true;
		boolean m=true;
		boolean j=true;
		boolean k=true;
		boolean l=true;
		int count1=0;
		int count2=0;
	char[] arr=number.toCharArray();
	if(number.length()==17) {
		if(number.substring(0,4).contentEquals("+55 "))
			t=true;
		else return t=false;
		
		if((arr[6]==' ') &&( arr[12]=='-')) 
			m=true;
			else return m=false;
			
		
			
			for(int i=4;i<=5;i++) {
		   if(arr[i]>=48 && arr[i]<=57) {
			   count1++;
			  // System.out.println(count1);
						j=true;
		   }
					else  
					return j=false;
				 }
			for(int p=7;p<number.length();p++) {
				 if(arr[p]>='0' && arr[p]<='9') {
					 count2++;
					 k=true;
				 }
					else  
					 k=false;
				 }
			
			
	
		if(t && k &&  m && j && count1==2  && count2==9) 
			l=true;
		else l=false;
		
		return l;
	}
	
		//System.out.println("Invalid phone number format");
	return false;
	}
	}
	
