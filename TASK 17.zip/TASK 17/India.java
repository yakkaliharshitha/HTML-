

class India extends country {

	@Override
	public boolean phoneNumberFormat(String number) {
		boolean t=true;
		boolean k=true;
		boolean l=true;
		int count=0;
		char[] arr=number.toCharArray();
		if(number.length()==14) {
			
			if(number.substring(0,4).contentEquals("+91-"))
				t=true;
			else  t=false;
			       
			 for(int i=4;i<number.length();i++) {
				 if(arr[i]>=48 && arr[i]<=57) {
					 count++;
					// System.out.println(count);
					
						k=true;
				 }
					else  
				 k=false;
				 }
				
		if(t && k && count==10) 
			l=true;
		
		else { 
			t=false;
			//System.out.println("wrong");
		}
		
		
		return l;
		}
		
		
		return false;
	}

		
		}




