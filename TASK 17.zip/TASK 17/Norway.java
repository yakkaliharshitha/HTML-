

class Norway extends country {
	@Override
	public boolean phoneNumberFormat(String number) {
		boolean t=true;
		boolean j=true;
		boolean k=true;
		boolean l=true;
		int count=0;
	char[] arr=number.toCharArray();
	if(number.length()==15) {
		if(number.substring(0,4).contentEquals("+47-")) {
			t=true;
			}
		else return t=false;
		
		if((arr[6]=='-') &&( arr[9]=='-')&&(arr[12]=='-')) 
				j=true;
			else return j=false;
				
		for(int i=4;i<number.length();i++) {
			 if((arr[i]>='0' && arr[i]<='9')) { 
				   count++;
				  // System.out.println(count);
					 k=true;
			 }
				else  
				 k=false;
			 }
		if(t && k && j && count==8) {
			
			return l=true;
		}
		else l=false;
	}
	
	return false;
	}
		
	}
