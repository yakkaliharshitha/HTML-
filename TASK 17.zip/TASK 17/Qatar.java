
public class Qatar extends country {
	@Override
	public boolean phoneNumberFormat(String number) {
		boolean t=true;
		boolean m=true;
		boolean k=true;
		boolean l=true;
		int count=0;
	char[] arr=number.toCharArray();
		if(number.length()==14) {
			if(number.substring(0,5).contentEquals("+974 ")) {
				t=true;
			}
			else return t=false;
			
			
			for(int i=5;i<number.length();i++) {
				//System.out.println("In loop");
				 if(arr[i]>='0' && arr[i]<='9') {
					 count++;
					// System.out.println(arr[i]);
						k=true;
				 }
					else  
					k=false;
				 }
			
			if(arr[9]=='-') {
				m=true;
			}
			else return m=false;
				
			
			
		//else return false;
		if(t && k && m && count==8)
			l=true;
		else l=false;
		
		return l;
		}
		
	 return false;
}

	
}
