
public class Interfacetask {

public static void main(String[] args) {

	
	India i=new India();
	System.out.println(i.phoneNumberFormat("+91-888555AAAA"));
	Brazil b=new Brazil();
	System.out.println(b.phoneNumberFormat("+55 15 99999-9999"));
	Norway n=new Norway();
	System.out.println(n.phoneNumberFormat("+47-49-99-99-99"));
	Qatar q = new Qatar();
	System.out.println(q.phoneNumberFormat("+974 3399-9999"));
	Turkey t= new Turkey();
	System.out.println(t.phoneNumberFormat("+90 509-999999"));
	
	}

}
