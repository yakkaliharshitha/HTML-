
interface Phonenumber
{
	 boolean phoneNumberFormat(String number);
	 
}
abstract class country implements Phonenumber {
	
}
	

	
		
	
	
	