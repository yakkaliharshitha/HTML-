import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/dxc.model';

import { DxcUsersDaoService } from '../dxc-users-dao.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private daosrv:DxcUsersDaoService,private router:Router)
  {
  
   
  }
    user:User={"user_ID":0,"user_Name":"","user_password":"" ,"user_FullName":"","user_SecurityQuestion":"","user_SecurityAnswer":""};
  
  saveUser()
  {
  
  this.daosrv.saveUser(this.user).subscribe(
  data=>console.log(data),
  error=>console.log(error)
  
  );
  alert("Successfully Registered")
  this.router.navigate(['login'])
  }


  ngOnInit(): void {
  }

}
