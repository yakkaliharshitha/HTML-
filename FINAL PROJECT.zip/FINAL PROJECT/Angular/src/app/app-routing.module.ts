import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddcartComponent } from './addcart/addcart.component';
import { CarComponent } from './car/car.component';
import { CardComponent } from './card/card.component';
import { CarddetailsComponent } from './carddetails/carddetails.component';
import { ChangepassComponent } from './changepass/changepass.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { CodComponent } from './cod/cod.component';
import { CartComponent } from './components/cart/cart.component';
import { ProductComponent } from './components/product/product.component';
import { ForgetComponent } from './forget/forget.component';
import { GetComponent } from './get/get.component';
import { GetaddrComponent } from './getaddr/getaddr.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { ProComponent } from './pro/pro.component';
import { RegisterComponent } from './register/register.component';
import { SearchComponent } from './search/search.component';
import { UpiComponent } from './upi/upi.component';

const routes: Routes = [
  {path:'', redirectTo:'login',pathMatch:'full'},
  {path:'login',component:LoginpageComponent},
  {path:'home',component:HomepageComponent},
  {path:'register',component:RegisterComponent},
  {path:'forget',component:ForgetComponent},
  {path:'changepass',component:ChangepassComponent},
  {path:'car',component:CarComponent},
  {path:'get',component:GetComponent},
  {path:'getaddr',component:GetaddrComponent},
  { path: 'product', component: ProComponent },
  { path: 'addcart', component:AddcartComponent },
  { path: 'upi', component:UpiComponent },
  { path: 'card', component:CardComponent },
  { path: 'cod', component: CodComponent},
  { path: 'checkout', component: CheckoutComponent},
  { path: 'carddetails', component:CarddetailsComponent},
  { path: 'product', redirectTo: 'addcart' },
  {path:'search',component:SearchComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routing = RouterModule.forRoot(routes);
