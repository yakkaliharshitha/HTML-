import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upidetails',
  templateUrl: './upidetails.component.html',
  styleUrls: ['./upidetails.component.css']
})
export class UpidetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
