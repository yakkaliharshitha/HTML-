import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/dxc.model';
import { DxcUsersDaoService } from '../dxc-users-dao.service';

@Component({
  selector: 'app-changepass',
  templateUrl: './changepass.component.html',
  styleUrls: ['./changepass.component.css']
})
export class ChangepassComponent implements OnInit {

  constructor(private router:Router,private daosrv:DxcUsersDaoService) { }
 newPassword:string
  confirmNewPassword:string
  user_Name:string
  currentpassword:string


  ngOnInit(): void {
  }
  user3:User={"user_ID":0,"user_Name":"","user_password":"" ,"user_FullName":"","user_SecurityQuestion":"","user_SecurityAnswer":""};
  updatePassword()
  {
     this.user_Name=localStorage.getItem('username')
      if(this.newPassword.length==0 || this.confirmNewPassword.length==0)
      {
        alert("Empty new password");
      }
      else
      {
        if(this.newPassword===this.confirmNewPassword)
        {
          this.user3.user_password=this.newPassword;
          console.log(this.user_Name)
          console.log(this.newPassword)
          this.daosrv.changepass(this.user_Name,this.newPassword,this.user3).subscribe(

            error=>console.log(error)
            
          );
          
          alert("Password Successfully Changed!!");
          this.router.navigate(['login']);
        }
        else
        {
          alert(" New Password Mismatch")
        }
      }
    
    
    }
    
  }



