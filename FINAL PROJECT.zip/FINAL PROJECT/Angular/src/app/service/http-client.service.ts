import { Injectable } from '@angular/core';
import { StoreUser } from '../model/User';
import { HttpClient } from '@angular/common/http';
import { StoreBook } from '../model/Book';

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {
  [x: string]: any;

  constructor(
    private httpClient:HttpClient
  ) { }
  getAll()
  {
    console.log('Getting all users');
    return this.httpClient.get<StoreUser[]>('http://localhost:1112/rest');
  }
  addUser(newUser: StoreUser) {
    return this.httpClient.post<StoreUser>('http://localhost:1112/add', newUser);   
  }
  getAllbooks()
  {
    console.log('Getting all books');
    return this.httpClient.get<StoreBook[]>('http://localhost:1112/restbook');
  }
  addBook(newBook: StoreBook) {
    return this.httpClient.post<StoreBook>('http://localhost:1112/addbook', newBook);
  }
}
