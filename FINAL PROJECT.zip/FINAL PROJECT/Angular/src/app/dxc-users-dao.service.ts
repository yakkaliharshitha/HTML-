import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/dxc.model';


@Injectable({
  providedIn: 'root'
})
export class DxcUsersDaoService {

  constructor(private http:HttpClient) { 
    

  }
  saveUser(user:User)
{

 return this.http.post<any>('http://localhost:1111/saveuser',user); 
}
loginuser(user_Name:String)
{
  return this.http.get<any>(`http://localhost:1111/search/${user_Name}`); 
}
forget(user_Name:String)
{
  return this.http.get<any>(`http://localhost:1111/search/${user_Name}`); 
}
changepass(user_Name:string,newPassword:string,user:User)
{
  return this.http.put<any>(`http://localhost:1111/update/${user_Name}/${newPassword}`,user); 
}
getAllDetails()
{
  return this.http.get<any>('http://localhost:1111/vechilegetall'); 
}

}