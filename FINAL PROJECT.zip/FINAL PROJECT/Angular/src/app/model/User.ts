export class StoreUser {
    id: number;
    name: string;
    type: string;  
    password: string;
  }