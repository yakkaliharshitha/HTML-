import { Injectable } from '@angular/core';

import { Product } from '../entities/product.entity';

@Injectable()
export class ProductService {

    private products: Product[];

    constructor() {
        this.products = [
            { id : '1', vechmodel : 'Creta', vechtype: 'car',vechbrand:'Hyundai', vechnumber : 20, vechcost:'Rs.20.57 Lakh',vechimage:'imgg1.jpg',vechcc:'1493',vechmilage:'18.5 kmpl',vechpower:'113.42bhp@4000rpm'},
            { id : '2', vechmodel : 'Santro', vechtype: 'car',vechbrand:'Hyundai', vechnumber : 20, vechcost:'Rs.5.81 Lakh',vechimage:'img2.jpg',vechcc:'1086',vechmilage:'20.3 kmpl',vechpower:'68.07bhp@5500rpm'},
            { id : '3', vechmodel : 'Xcent', vechtype: 'car',vechbrand:'Hyundai', vechnumber : 20, vechcost:'Rs. 17.6 Lakh',vechimage:'img3.jpg',vechcc:'1186',vechmilage:'25.4 kmpl(ARAI)/ 19.04 kmpl(city)',vechpower:'73.97bhp@4000rpm'},       
            { id : '4', vechmodel : 'Vellfire', vechtype: 'car',vechbrand:'Toyota', vechnumber : 20, vechcost:'Rs.83.5 Lakh',vechimage:'img4.jpg',vechcc:'2494',vechmilage:'16 kmpl',vechpower:'115.3bhp@4700rpm'},  
            { id : '5', vechmodel : 'Camry', vechtype: 'car',vechbrand:'Toyota', vechnumber : 20, vechcost:'Rs. 39.02 Lakh',vechimage:'img5.jpg',vechcc:'2487',vechmilage:' 19.16 kmpl',vechpower:'214.5bhp@5700rpm'},
            { id : '6', vechmodel : 'Prius', vechtype: 'car',vechbrand:'Toyota', vechnumber : 20, vechcost:'Rs. 45.09 Lakh',vechimage:'img6.jpg',vechcc:'1798',vechmilage:' 26.27 kmpl',vechpower:' 96.55 bhp@5200rpm'},
            { id : '7', vechmodel : 'X3', vechtype: 'car',vechbrand:'BMW', vechnumber : 20, vechcost:'Rs. 60.5-60.9 Lakh',vechimage:'img7.jpg',vechcc:' 1995 to 1998',vechmilage:'13.17 to 16.55 kmpl',vechpower:' 187.7bhp@4000rpm'},
            { id : '8', vechmodel : '5 Series', vechtype: 'car',vechbrand:'BMW', vechnumber : 20, vechcost:'Rs. 55.4-68.4  Lakh',vechimage:'img8.jpg',vechcc:'1995 to 2993',vechmilage:'15.01 to 20.37 kmpl',vechpower:'261.49bhp@4000rpm'},
            { id : '9', vechmodel : 'X4', vechtype: 'car',vechbrand:'BMW', vechnumber : 20, vechcost:'Rs. 62.4-67.9 Lakh',vechimage:'img9.jpg',vechcc:'2993',vechmilage:'14.71 kmpl',vechpower:'265bhp@4000rpm'},
            { id : '10', vechmodel : 'Sp 125', vechtype: 'Bike',vechbrand:'Honda', vechnumber : 20, vechcost:'Rs. 74,407',vechimage:'b1.jpg',vechcc:'124',vechmilage:': 65 kmpl',vechpower:'10.72bhp@7500rpm'},
            { id : '11', vechmodel : 'Livo BS6', vechtype: 'Bike',vechbrand:'Honda', vechnumber : 20, vechcost:'Rs. 70,056',vechimage:'b2.jpg',vechcc:'109',vechmilage:'60-70 kmpl',vechpower:'8.31bhp@7500rpm'},
            { id : '12', vechmodel : 'XBlade', vechtype: 'Bike',vechbrand:'Honda', vechnumber : 20, vechcost:'Rs. 1.06 Lakh',vechimage:'b3.jpg',vechcc:' 162.71',vechmilage:'50 kmpl',vechpower:' 8.31bhp@8000rpm'},       
            { id : '13', vechmodel : 'Himalayan', vechtype: 'Bike',vechbrand:'Royal Enfield', vechnumber : 20, vechcost:'Rs. 1.89Lakh',vechimage:'b4.jpg',vechcc:'411',vechmilage:'30 kmpl',vechpower:'24.3 bhp @ 6,500 rpm'},  
            { id : '14', vechmodel : 'Interceptor 650', vechtype: 'Bike',vechbrand:'Royal Enfield', vechnumber : 20, vechcost:'Rs. 2.64 Lakh',vechimage:'b5.jpg',vechcc:'648',vechmilage:'25 kmpl',vechpower:'47 bhp @ 7,250 rpm'},
            { id : '15', vechmodel : 'Continental GT 650', vechtype: 'Bike',vechbrand:'Royal Enfield', vechnumber : 20, vechcost:'Rs. 2.8 Lakh',vechimage:'b6.png',vechcc:'648',vechmilage:'25kmpl',vechpower:'47 bhp@ 7,250 rpm'},
            { id : '16', vechmodel : '200 Duke', vechtype: 'Bike',vechbrand:'KTM', vechnumber : 20, vechcost:'Rs. 1.76 Lakh',vechimage:'b7.jpg',vechcc:'199.5',vechmilage:'34 kmpl',vechpower:'24.6 bhp @ 10,000 rpm'},
            { id : '17', vechmodel : '125 Duke', vechtype: 'Bike',vechbrand:'KTM', vechnumber : 20, vechcost:'Rs. 1.42 Lakh',vechimage:'b8.jpg',vechcc:'124.71',vechmilage:'40 kmpl',vechpower:'14.3 bhp @ 9,250 rpm'},
            { id : '18', vechmodel : 'RC 200', vechtype: 'Bike',vechbrand:'KTM', vechnumber : 20, vechcost:'Rs. 2 Lakh',vechimage:'b9.jpg',vechcc:'199.5',vechmilage:'31 kmpl',vechpower:'24.6 bhp @ 10,000 rpm'}
            
            
        ];
    }

    findAll(): Product[] {
        return this.products;
    }

    find(id: string): Product {
        return this.products[this.getSelectedIndex(id)];
    }

    private getSelectedIndex(id: string) {
        for (var i = 0; i < this.products.length; i++) {
            if (this.products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

}