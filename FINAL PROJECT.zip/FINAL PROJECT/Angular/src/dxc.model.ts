export class User
{
    user_ID:number;
	user_FullName:String;
	user_Name:string;
	 user_password:String;
   user_SecurityQuestion:String;
	 user_SecurityAnswer:string;
}