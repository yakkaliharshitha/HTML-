package mongodb.spring.demo.mongodb.spring.restapi.model;

import java.util.Arrays;

import org.springframework.data.annotation.Id;
import org.springframework.stereotype.Component;

@Component
public class ShowVechiles {
	
	@Id
	int vechid;
	String vechmodel;
    String vechtype;
    String vechbrand;
	int vechnumber;
	String vechcost;
	String vechimage;
	public int getVechid() {
		return vechid;
	}
	public void setVechid(int vechid) {
		this.vechid = vechid;
	}
	public String getVechmodel() {
		return vechmodel;
	}
	public void setVechmodel(String vechmodel) {
		this.vechmodel = vechmodel;
	}
	public String getVechtype() {
		return vechtype;
	}
	public void setVechtype(String vechtype) {
		this.vechtype = vechtype;
	}
	public String getVechbrand() {
		return vechbrand;
	}
	public void setVechbrand(String vechbrand) {
		this.vechbrand = vechbrand;
	}
	public int getVechnumber() {
		return vechnumber;
	}
	public void setVechnumber(int vechnumber) {
		this.vechnumber = vechnumber;
	}
	public String getVechcost() {
		return vechcost;
	}
	public void setVechcost(String vechcost) {
		this.vechcost = vechcost;
	}
	public String getVechimage() {
		return vechimage;
	}
	public void setVechimage(String vechimage) {
		this.vechimage = vechimage;
	}
	@Override
	public String toString() {
		return "ShowVechiles [vechid=" + vechid + ", vechmodel=" + vechmodel + ", vechtype=" + vechtype + ", vechbrand="
				+ vechbrand + ", vechnumber=" + vechnumber + ", vechcost=" + vechcost + ", vechimage=" + vechimage
				+ "]";
	}
	public ShowVechiles(int vechid, String vechmodel, String vechtype, String vechbrand, int vechnumber,
			String vechcost, String vechimage) {
		super();
		this.vechid = vechid;
		this.vechmodel = vechmodel;
		this.vechtype = vechtype;
		this.vechbrand = vechbrand;
		this.vechnumber = vechnumber;
		this.vechcost = vechcost;
		this.vechimage = vechimage;
	}
	public ShowVechiles() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
