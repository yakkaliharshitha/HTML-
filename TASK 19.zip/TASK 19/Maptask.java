import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import java.util.Scanner;
public class Maptask {
public static void main(String[]args) {

		Book b1=new Book(23476,"The Taj Mahal","R.JRahul");
		Book b2=new Book(25823,"The Life","R.V.David");
		Book b3=new Book(98665,"The Boy Who Loved","C.Shankar");
		Book b4=new Book(65478,"The Mughal Era","P.C.Madhavi");
		Book b5=new Book(76589,"Akbar The Great","H.M.Guru");
		
		HashMap<Integer, Book> h=new HashMap();
		h.put(b1.getIsbn(), b1);
		h.put(b2.getIsbn(), b2);
		h.put(b3.getIsbn(), b3);
		h.put(b4.getIsbn(), b4);
		h.put(b5.getIsbn(), b5);
   
		
    int s=Integer.parseInt(args[0]);
		Book sd= h.get(s);
      //System.out.println(sd);
      Set<Integer> keys=h.keySet();
      Iterator<Integer> itr= keys.iterator();
      while(itr.hasNext())
      {
      int key=itr.next();
     System.out.println(key +"  "+ h.get(key));

}
      
	}

}
