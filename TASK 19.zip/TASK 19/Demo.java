import java.util.HashSet;
import java.util.Iterator;

public class Demo {

	public static void main(String[] args) {
		HashSet<Book> hs=new HashSet<>();

		Book b1=new Book(23476,"The Taj Mahal","R.JRahul");
		Book b2=new Book(25823,"The Life","R.V.David");
		Book b3=new Book(98665,"The Boy Who Loved","C.Shankar");
		Book b4=new Book(65478,"The Mughal Era","P.C.Madhavi");
		Book b5=new Book(76589,"Akbar The Great","H.M.Guru");
		//Book b6=new Book(23476,"The Taj Mahal","R.JRahul");
		
		hs.add(b1);
		hs.add(b2);
		hs.add(b3);
		hs.add(b4);
		hs.add(b5);
		hs.add(b1);
		//System.out.println(hs);
		
	Iterator<Book> it=hs.iterator();
      //Book hsObject=it.next();
	//	hsObject.display();
		//it.next().display();
       while(it.hasNext())
		{
		it.next().display();
		}

		}


	}


