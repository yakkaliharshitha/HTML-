import java.util.Vector;
public class Vectortask {
	public static void main(String[]args) {
	Vector<Integer> marks=new Vector<Integer>(20);
	
	marks.add(40);
	marks.add(54);
	marks.add(60);
	marks.add(65);
	int m=66;
	marks.add(m);
	marks.add(67);
	marks.add(70);
	marks.add(72);
	marks.add(76);
	marks.add(80);

	int n=85;
	marks.add(n);

	System.out.println(marks);
	
	marks.remove(5);
	System.out.println(marks);
	}
}
